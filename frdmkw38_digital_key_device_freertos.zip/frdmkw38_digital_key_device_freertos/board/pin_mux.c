/*
 * Copyright 2020 NXP
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of the copyright holder nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/* clang-format off */
/*
 * TEXT BELOW IS USED AS SETTING FOR TOOLS *************************************
!!GlobalInfo
product: Pins v5.0
processor: MKW38A512xxx4
package_id: MKW38A512VFT4
mcu_data: ksdk2_0
processor_version: 0.0.0
pin_labels:
- {pin_num: '37', pin_signal: PTC1/I2C0_SDA/LPUART0_RTS_b/TPM0_CH2/SPI1_SCK, label: LED_R, identifier: LED_R}
- {pin_num: '4', pin_signal: PTA16/LLWU_P4/SPI1_SOUT/LPUART1_RTS_b/TPM0_CH0, label: LED_G, identifier: LED_G}
- {pin_num: '18', pin_signal: ADC0_SE3/CMP0_IN3/PTB2/LLWU_P9/TPM0_CH0/TPM1_CH0/TPM2_CH0, label: LED_B, identifier: LED_B}
- {pin_num: '19', pin_signal: ADC0_SE2/CMP0_IN4/PTB3/ERCLK32K/LPUART1_RTS_b/TPM0_CH1/CLKOUT/TPM1_CH1/RTC_CLKOUT/TPM2_CH1, label: LED, identifier: LED}
- {pin_num: '23', pin_signal: ADC0_SE4/CMP0_IN2/PTB18/LPUART1_CTS_b/I2C1_SCL/TPM_CLKIN0/TPM0_CH0/NMI_b, label: SW2, identifier: SW2}
- {pin_num: '38', pin_signal: PTC2/LLWU_P10/I2C1_SCL/LPUART0_RX/CMT_IRO/SPI1_SOUT, label: SW3, identifier: SW3}
- {pin_num: '42', pin_signal: PTC6/LLWU_P14/I2C1_SCL/LPUART0_RX/TPM2_CH0, label: LPUART0_RX, identifier: LPUART0_RX}
- {pin_num: '43', pin_signal: PTC7/LLWU_P15/SPI0_PCS2/I2C1_SDA/LPUART0_TX/TPM2_CH1, label: LPUART0_TX, identifier: LPUART0_TX}
- {pin_num: '6', pin_signal: PTA18/LLWU_P6/SPI1_SCK/LPUART1_TX/CAN0_RX/TPM2_CH0, label: LPUART1_TX, identifier: LPUART1_TX}
- {pin_num: '5', pin_signal: PTA17/LLWU_P5/SPI1_SIN/LPUART1_RX/CAN0_TX/TPM_CLKIN1, label: LPUART1_RX, identifier: LPUART1_RX}
 * BE CAREFUL MODIFYING THIS COMMENT - IT IS YAML SETTINGS FOR TOOLS ***********
 */
/* clang-format on */

#include "fsl_common.h"
#include "fsl_port.h"
#include "fsl_gpio.h"
#include "pin_mux.h"
#include "board.h"
/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitBootPins
 * Description   : Calls initialization functions.
 *
 * END ****************************************************************************************************************/
void BOARD_InitBootPins(void)
{
    BOARD_InitLPUART();
    BOARD_InitLEDs();
    BOARD_InitButtons();
}

/* clang-format off */
/*
 * TEXT BELOW IS USED AS SETTING FOR TOOLS *************************************
BOARD_InitLPUART:
- options: {callFromInitBoot: 'true', coreID: core0, enableClock: 'true'}
- pin_list:
  - {pin_num: '42', peripheral: LPUART0, signal: RX, pin_signal: PTC6/LLWU_P14/I2C1_SCL/LPUART0_RX/TPM2_CH0}
  - {pin_num: '43', peripheral: LPUART0, signal: TX, pin_signal: PTC7/LLWU_P15/SPI0_PCS2/I2C1_SDA/LPUART0_TX/TPM2_CH1}
 * BE CAREFUL MODIFYING THIS COMMENT - IT IS YAML SETTINGS FOR TOOLS ***********
 */
/* clang-format on */

/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitLPUART
 * Description   : Configures pin routing and optionally pin electrical features.
 *
 * END ****************************************************************************************************************/
void BOARD_InitLPUART(void)
{
    /* Port C Clock Gate Control: Clock enabled */
    CLOCK_EnableClock(kCLOCK_PortC);

    /* PORTC6 (pin 42) is configured as LPUART0_RX */
    PORT_SetPinMux(BOARD_INITLPUART_LPUART0_RX_PORT, BOARD_INITLPUART_LPUART0_RX_PIN, kPORT_MuxAlt4);

    /* PORTC7 (pin 43) is configured as LPUART0_TX */
    PORT_SetPinMux(BOARD_INITLPUART_LPUART0_TX_PORT, BOARD_INITLPUART_LPUART0_TX_PIN, kPORT_MuxAlt4);

    SIM->SOPT5 = ((SIM->SOPT5 &
                   /* Mask bits to zero which are setting */
                   (~(SIM_SOPT5_LPUART0TXSRC_MASK | SIM_SOPT5_LPUART0RXSRC_MASK)))

                  /* LPUART0 Transmit Data Source Select: LPUART0_TX pin. */
                  | SIM_SOPT5_LPUART0TXSRC(SOPT5_LPUART0TXSRC_0b00)

                  /* LPUART0 Receive Data Source Select: LPUART_RX pin. */
                  | SIM_SOPT5_LPUART0RXSRC(SOPT5_LPUART0RXSRC_0b0));
}

/* clang-format off */
/*
 * TEXT BELOW IS USED AS SETTING FOR TOOLS *************************************
BOARD_InitLEDs:
- options: {callFromInitBoot: 'true', coreID: core0, enableClock: 'true'}
- pin_list:
  - {pin_num: '19', peripheral: GPIOB, signal: 'GPIO, 3', pin_signal: ADC0_SE2/CMP0_IN4/PTB3/ERCLK32K/LPUART1_RTS_b/TPM0_CH1/CLKOUT/TPM1_CH1/RTC_CLKOUT/TPM2_CH1,
    direction: OUTPUT}
  - {pin_num: '37', peripheral: GPIOC, signal: 'GPIO, 1', pin_signal: PTC1/I2C0_SDA/LPUART0_RTS_b/TPM0_CH2/SPI1_SCK, direction: OUTPUT}
  - {pin_num: '18', peripheral: GPIOB, signal: 'GPIO, 2', pin_signal: ADC0_SE3/CMP0_IN3/PTB2/LLWU_P9/TPM0_CH0/TPM1_CH0/TPM2_CH0, direction: OUTPUT}
  - {pin_num: '4', peripheral: GPIOA, signal: 'GPIO, 16', pin_signal: PTA16/LLWU_P4/SPI1_SOUT/LPUART1_RTS_b/TPM0_CH0, direction: OUTPUT}
 * BE CAREFUL MODIFYING THIS COMMENT - IT IS YAML SETTINGS FOR TOOLS ***********
 */
/* clang-format on */

/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitLEDs
 * Description   : Configures pin routing and optionally pin electrical features.
 *
 * END ****************************************************************************************************************/
void BOARD_InitLEDs(void)
{
    /* Port A Clock Gate Control: Clock enabled */
    CLOCK_EnableClock(kCLOCK_PortA);
    /* Port B Clock Gate Control: Clock enabled */
    CLOCK_EnableClock(kCLOCK_PortB);
    /* Port C Clock Gate Control: Clock enabled */
    CLOCK_EnableClock(kCLOCK_PortC);

    gpio_pin_config_t LED_G_config = {
        .pinDirection = kGPIO_DigitalOutput,
        .outputLogic = 0U
    };
    /* Initialize GPIO functionality on pin PTA16 (pin 4)  */
    GPIO_PinInit(BOARD_INITLEDS_LED_G_GPIO, BOARD_INITLEDS_LED_G_PIN, &LED_G_config);

    gpio_pin_config_t LED_B_config = {
        .pinDirection = kGPIO_DigitalOutput,
        .outputLogic = 0U
    };
    /* Initialize GPIO functionality on pin PTB2 (pin 18)  */
    GPIO_PinInit(BOARD_INITLEDS_LED_B_GPIO, BOARD_INITLEDS_LED_B_PIN, &LED_B_config);

    gpio_pin_config_t LED_config = {
        .pinDirection = kGPIO_DigitalOutput,
        .outputLogic = 0U
    };
    /* Initialize GPIO functionality on pin PTB3 (pin 19)  */
    GPIO_PinInit(BOARD_INITLEDS_LED_GPIO, BOARD_INITLEDS_LED_PIN, &LED_config);

    gpio_pin_config_t LED_R_config = {
        .pinDirection = kGPIO_DigitalOutput,
        .outputLogic = 0U
    };
    /* Initialize GPIO functionality on pin PTC1 (pin 37)  */
    GPIO_PinInit(BOARD_INITLEDS_LED_R_GPIO, BOARD_INITLEDS_LED_R_PIN, &LED_R_config);

    /* PORTA16 (pin 4) is configured as PTA16 */
    PORT_SetPinMux(BOARD_INITLEDS_LED_G_PORT, BOARD_INITLEDS_LED_G_PIN, kPORT_MuxAsGpio);

    /* PORTB2 (pin 18) is configured as PTB2 */
    PORT_SetPinMux(BOARD_INITLEDS_LED_B_PORT, BOARD_INITLEDS_LED_B_PIN, kPORT_MuxAsGpio);

    /* PORTB3 (pin 19) is configured as PTB3 */
    PORT_SetPinMux(BOARD_INITLEDS_LED_PORT, BOARD_INITLEDS_LED_PIN, kPORT_MuxAsGpio);

    /* PORTC1 (pin 37) is configured as PTC1 */
    PORT_SetPinMux(BOARD_INITLEDS_LED_R_PORT, BOARD_INITLEDS_LED_R_PIN, kPORT_MuxAsGpio);
}

/* clang-format off */
/*
 * TEXT BELOW IS USED AS SETTING FOR TOOLS *************************************
BOARD_InitButtons:
- options: {callFromInitBoot: 'true', coreID: core0, enableClock: 'true'}
- pin_list:
  - {pin_num: '23', peripheral: GPIOB, signal: 'GPIO, 18', pin_signal: ADC0_SE4/CMP0_IN2/PTB18/LPUART1_CTS_b/I2C1_SCL/TPM_CLKIN0/TPM0_CH0/NMI_b, direction: INPUT,
    pull_enable: enable}
  - {pin_num: '38', peripheral: GPIOC, signal: 'GPIO, 2', pin_signal: PTC2/LLWU_P10/I2C1_SCL/LPUART0_RX/CMT_IRO/SPI1_SOUT, direction: INPUT, pull_enable: enable}
 * BE CAREFUL MODIFYING THIS COMMENT - IT IS YAML SETTINGS FOR TOOLS ***********
 */
/* clang-format on */

/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitButtons
 * Description   : Configures pin routing and optionally pin electrical features.
 *
 * END ****************************************************************************************************************/
void BOARD_InitButtons(void)
{
    /* Port B Clock Gate Control: Clock enabled */
    CLOCK_EnableClock(kCLOCK_PortB);
    /* Port C Clock Gate Control: Clock enabled */
    CLOCK_EnableClock(kCLOCK_PortC);

    gpio_pin_config_t SW2_config = {
        .pinDirection = kGPIO_DigitalInput,
        .outputLogic = 0U
    };
    /* Initialize GPIO functionality on pin PTB18 (pin 23)  */
    GPIO_PinInit(BOARD_INITBUTTONS_SW2_GPIO, BOARD_INITBUTTONS_SW2_PIN, &SW2_config);

    gpio_pin_config_t SW3_config = {
        .pinDirection = kGPIO_DigitalInput,
        .outputLogic = 0U
    };
    /* Initialize GPIO functionality on pin PTC2 (pin 38)  */
    GPIO_PinInit(BOARD_INITBUTTONS_SW3_GPIO, BOARD_INITBUTTONS_SW3_PIN, &SW3_config);

    /* PORTB18 (pin 23) is configured as PTB18 */
    PORT_SetPinMux(BOARD_INITBUTTONS_SW2_PORT, BOARD_INITBUTTONS_SW2_PIN, kPORT_MuxAsGpio);

    PORTB->PCR[18] = ((PORTB->PCR[18] &
                       /* Mask bits to zero which are setting */
                       (~(PORT_PCR_PE_MASK | PORT_PCR_ISF_MASK)))

                      /* Pull Enable: Internal pullup or pulldown resistor is enabled on the corresponding pin. */
                      | (uint32_t)(PORT_PCR_PE_MASK));

    /* PORTC2 (pin 38) is configured as PTC2 */
    PORT_SetPinMux(BOARD_INITBUTTONS_SW3_PORT, BOARD_INITBUTTONS_SW3_PIN, kPORT_MuxAsGpio);

    PORTC->PCR[2] = ((PORTC->PCR[2] &
                      /* Mask bits to zero which are setting */
                      (~(PORT_PCR_PE_MASK | PORT_PCR_ISF_MASK)))

                     /* Pull Enable: Internal pullup or pulldown resistor is enabled on the corresponding pin. */
                     | (uint32_t)(PORT_PCR_PE_MASK));
}
/*! *********************************************************************************
 *     CCC demo PINs Initialization functions
 ********************************************************************************** */
#if CCC_DIG_KEY_R3_DEMO_ENABLE
/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitDebug
 * Description   : Calls debug console initialization functions
 * 
 *
 * END ****************************************************************************************************************/
void BOARD_InitDebug(void)
{
    /*Initialize Uart (Debug Console) */
//#if defined(gDebugConsoleEnable_d) && (gDebugConsoleEnable_d == 1)
//    BOARD_InitLPUART();
//#endif
    BOARD_InitDebugConsole();
}


/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitSPI0Pin
 * Description   : Init SPI0 pins, CS pin will be manually controlled for SPI .
 *
 * END ****************************************************************************************************************/
void BOARD_InitSPI0Pins(void)
{
    /* Enable Clocks: Port C Gate Control */
    CLOCK_EnableClock(kCLOCK_PortC);
    
    /* SPI0_SCK: PORTC16 (pin 45) */
    PORT_SetPinMux(BOARD_SPI0_CLK_PORT, BOARD_SPI0_CLK_PIN, kPORT_MuxAlt2);
    /* SPI0_SOUT: PORTC17 (pin 46) */
    PORT_SetPinMux(BOARD_SPI0_MISO_PORT, BOARD_SPI0_MISO_PIN, kPORT_MuxAlt2);
    /* SPI0_SIN: PORTC18 (pin 47) */
    PORT_SetPinMux(BOARD_SPI0_MOSI_PORT, BOARD_SPI0_MOSI_PIN, kPORT_MuxAlt2);
    /* SPI0_CS: PORTC19 (pin 48) */
    //PORT_SetPinMux(PORTC, PIN19_IDX, kPORT_MuxAlt2);           
}

/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitSPI1Pin
 * Description   : Init SPI0 pins, CS pin will be manually controlled for SPI.
 *                 
 * END ****************************************************************************************************************/
void BOARD_InitSPI1Pins(void)
{
    /* Enable Clocks: Port A Gate Control */
    CLOCK_EnableClock(kCLOCK_PortA);
    
    /* SPI1_SOUT: PORTA16 (pin 4) */
    PORT_SetPinMux(BOARD_SPI1_MISO_PORT, BOARD_SPI1_MISO_PIN, kPORT_MuxAlt2);
    /* SPI1_SIN: PORTA17 (pin 5) */
    PORT_SetPinMux(BOARD_SPI1_MOSI_PORT, BOARD_SPI1_MOSI_PIN, kPORT_MuxAlt2);
    /* SPI1_SCK: PORTA18 (pin 6) */
    PORT_SetPinMux(BOARD_SPI1_CLK_PORT, BOARD_SPI1_CLK_PIN, kPORT_MuxAlt2);
    /* SPI0_CS: PORTA19 (pin 7) */
    //PORT_SetPinMux(PORTC, PIN19_IDX, kPORT_MuxAlt2);      
}

/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitFlexcan
 * Description   : FlexCAN Initialize Pins for CAN Communication
 *
 * END ****************************************************************************************************************/
void BOARD_InitFlexcan(void)
{
#if FLEXCAN_SUPPORT
    /* Port C Clock Gate Control: Clock enabled */
    CLOCK_EnableClock(kCLOCK_PortC);

    /* PORTC3 (pin 39) is configured as CAN0_TX */
    PORT_SetPinMux(BOARD_INITFLEXCAN_CAN0_TX_PORT, BOARD_INITFLEXCAN_CAN0_TX_PIN, kPORT_MuxAlt9);

    /* PORTC4 (pin 40) is configured as CAN0_RX */
    PORT_SetPinMux(BOARD_INITFLEXCAN_CAN0_RX_PORT, BOARD_INITFLEXCAN_CAN0_RX_PIN, kPORT_MuxAlt9);
#endif
}

/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_InitRanger4Pins
 * Description   : Init UWB module connected Pins
 *
 * END ****************************************************************************************************************/
void BOARD_InitRanger4Pins(void)
{
    BOARD_InitSPI0Pins();
    
    /* Enable Clocks: Port A Gate Control */
    CLOCK_EnableClock(kCLOCK_PortA);
    /* Enable Clocks: Port C Gate Control */
    CLOCK_EnableClock(kCLOCK_PortC);
    /*** Manual chip select (CS): PORTA19 output***/
    PORT_SetPinMux(BOARD_UWB_CS_PORT, BOARD_UWB_CS_PIN, kPORT_MuxAsGpio);
    port_pin_config_t csPinconfig =
    {
        kPORT_PullDisable,
        kPORT_FastSlewRate,
        kPORT_PassiveFilterDisable,
        kPORT_LowDriveStrength,
        kPORT_MuxAsGpio
    };
    PORT_SetPinConfig(BOARD_UWB_CS_PORT, BOARD_UWB_CS_PIN, &csPinconfig);
    gpio_pin_config_t csPinGPIOConfig =
    {
        .outputLogic = 1u, 
        .pinDirection = kGPIO_DigitalOutput
    };
    GPIO_PinInit(BOARD_UWB_CS_GPIO, BOARD_UWB_CS_PIN, &csPinGPIOConfig);
    
    /*** Ready pin(RDY): PORTC5 input***/
    PORT_SetPinMux(BOARD_UWB_RDY_PORT, BOARD_UWB_RDY_PIN, kPORT_MuxAsGpio);
    port_pin_config_t readyPinconfig =
    {
        kPORT_PullUp,
        kPORT_FastSlewRate,
        kPORT_PassiveFilterEnable,
        kPORT_LowDriveStrength,
        kPORT_MuxAsGpio
    };
    PORT_SetPinConfig(BOARD_UWB_RDY_PORT, BOARD_UWB_RDY_PIN, &readyPinconfig);
    
    gpio_pin_config_t readyPinGPIOConfig =
    {
        .outputLogic = 1u,
        .pinDirection = kGPIO_DigitalInput
    };
    GPIO_PinInit(BOARD_UWB_RDY_GPIO, BOARD_UWB_RDY_PIN, &readyPinGPIOConfig);
    
    /*** Reset pin(RST): PORTC19 output***/
    PORT_SetPinMux(BOARD_UWB_RST_PORT, BOARD_UWB_RST_PIN, kPORT_MuxAsGpio);
    port_pin_config_t rstPinconfig =
    {
        kPORT_PullDisable,
        kPORT_FastSlewRate,
        kPORT_PassiveFilterDisable,
        kPORT_LowDriveStrength,
        kPORT_MuxAsGpio
    };
    PORT_SetPinConfig(BOARD_UWB_RST_PORT, BOARD_UWB_RST_PIN, &rstPinconfig);
    gpio_pin_config_t rstPinGPIOConfig =
    {
        .outputLogic = 1u,
        .pinDirection = kGPIO_DigitalOutput
    };
    GPIO_PinInit(BOARD_UWB_RST_GPIO, BOARD_UWB_RST_PIN, &rstPinGPIOConfig);
    
    /*** Interrupt pin: PORTC6 input***/
    // This port not use now. Because this port also be used by LpUart0, so 
    // it should be initlized after LpUart0 was initlized.  
    PORT_SetPinMux(BOARD_UWB_INt_PORT, BOARD_UWB_INT_PIN, kPORT_MuxAsGpio);
    port_pin_config_t intPinconfig =
    {
        kPORT_PullUp,
        kPORT_FastSlewRate,
        kPORT_PassiveFilterEnable,
        kPORT_LowDriveStrength,
        kPORT_MuxAsGpio
    };
    PORT_SetPinConfig(BOARD_UWB_INt_PORT, BOARD_UWB_INT_PIN, &intPinconfig);

    gpio_pin_config_t intPinGPIOConfig =
    {
        .outputLogic = 1u,
        .pinDirection = kGPIO_DigitalInput
    };
    GPIO_PinInit(BOARD_UWB_INT_GPIO, BOARD_UWB_INT_PIN, &intPinGPIOConfig);
}


/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_NFCPinsInit
 * Description   : Init NFC connected pins
 *
 * END ****************************************************************************************************************/
void BOARD_NFCPinsInit(void)
{
#if (NFC_FEATURE_SUPPORT == 1)    
    //BOARD_InitSPI0Pins();
    BOARD_InitSPI1Pins();
    
    /* Enable Clocks: Port B Gate Control */
    CLOCK_EnableClock(kCLOCK_PortB);
    /*** Manual chip select (CS): PORTB18 output***/
    PORT_SetPinMux(BOARD_NFC_CS_PORT, BOARD_NFC_CS_PIN, kPORT_MuxAsGpio);
    port_pin_config_t csPinconfig =
    {
        kPORT_PullDisable,
        kPORT_FastSlewRate,
        kPORT_PassiveFilterDisable,
        kPORT_LowDriveStrength,
        kPORT_MuxAsGpio
    };
    PORT_SetPinConfig(BOARD_NFC_CS_PORT, BOARD_NFC_CS_PIN, &csPinconfig);
    gpio_pin_config_t csPinGPIOConfig =
    {
        .outputLogic = 1u, 
        .pinDirection = kGPIO_DigitalOutput
    };
    GPIO_PinInit(BOARD_NFC_CS_GPIO, BOARD_NFC_CS_PIN, &csPinGPIOConfig);
    /*** Reset pin(RST): PORTB2 output***/
    PORT_SetPinMux(BOARD_NFC_RST_PORT, BOARD_NFC_RST_PIN, kPORT_MuxAsGpio);
    port_pin_config_t rstPinconfig =
    {
        kPORT_PullDisable,
        kPORT_FastSlewRate,
        kPORT_PassiveFilterDisable,
        kPORT_LowDriveStrength,
        kPORT_MuxAsGpio
    };
    PORT_SetPinConfig(BOARD_NFC_RST_PORT, BOARD_NFC_RST_PIN, &rstPinconfig);
    gpio_pin_config_t rstPinGPIOConfig =
    {
        .outputLogic = 1u,
        .pinDirection = kGPIO_DigitalOutput
    };
    GPIO_PinInit(BOARD_NFC_RST_GPIO, BOARD_NFC_RST_PIN, &rstPinGPIOConfig);
    
    /*** Interrupt pin: PORTB18 input***/
    PORT_SetPinMux(BOARD_NFC_INT_PORT, BOARD_NFC_INT_PIN, kPORT_MuxAsGpio);
    port_pin_config_t intPinconfig =
    {
        kPORT_PullDisable,
        kPORT_FastSlewRate,
        kPORT_PassiveFilterEnable,
        kPORT_LowDriveStrength,
        kPORT_MuxAsGpio
    };
    PORT_SetPinConfig(BOARD_NFC_INT_PORT, BOARD_NFC_INT_PIN, &intPinconfig);

    gpio_pin_config_t intPinGPIOConfig =
    {
        .outputLogic = 0u,
        .pinDirection = kGPIO_DigitalInput
    };
    GPIO_PinInit(BOARD_NFC_INT_GPIO, BOARD_NFC_INT_PIN, &intPinGPIOConfig);
#endif
}

/* FUNCTION ************************************************************************************************************
 *
 * Function Name : BOARD_SEPinsInit
 * Description   : Init SE connected pins
 *
 * END ****************************************************************************************************************/
void BOARD_SEPinsInit(void)
{
#if (SE_FEATURE_SUPPORT)

// SE and NFC share same SPI port, this function is called in SE_init task.In this project,
// SE_init is called later than NFC task, so it shouldn't init SPI port again if NFC feature 
// support since SPI may in use by NFC. But if not NFC, it need to initialize SPI    
#if (NFC_FEATURE_SUPPORT == 0)
    BOARD_InitSPI1Pins();
#endif
    /* Enable Clocks: Port B Gate Control */
    CLOCK_EnableClock(kCLOCK_PortC);
    /* CS pin: PORTC1 (pin 37) is configured as SPI1_PCS0*/
    PORT_SetPinMux(BOARD_ESE_CS_PORT, BOARD_ESE_CS_PIN, kPORT_MuxAsGpio);
    port_pin_config_t csPinconfig =
    {
        kPORT_PullDisable, /* Internal pull-up resistor is disabled */
        kPORT_FastSlewRate, /* Fast slew rate is configured */
        kPORT_PassiveFilterDisable, /* Passive filter is disabled */
        kPORT_LowDriveStrength, /* Low drive strength is configured */
        kPORT_MuxAsGpio /* Pin is configured as GPIO */
    };
    PORT_SetPinConfig(BOARD_ESE_CS_PORT, BOARD_ESE_CS_PIN, &csPinconfig);
    gpio_pin_config_t csPinGPIOConfig =
    {
        .outputLogic = 1u, 
        .pinDirection = kGPIO_DigitalOutput
    };
    GPIO_PinInit(BOARD_ESE_CS_GPIO, BOARD_ESE_CS_PIN, &csPinGPIOConfig);
    //GPIO_WritePinOutput(BOARD_ESE_CS_GPIO, BOARD_ESE_CS_PIN, 1);

    

#endif
}

#endif
/***********************************************************************************************************************
 * EOF
 **********************************************************************************************************************/

