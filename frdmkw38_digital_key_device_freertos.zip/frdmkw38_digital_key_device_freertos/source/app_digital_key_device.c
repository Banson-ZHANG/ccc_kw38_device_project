/*! *********************************************************************************
* \addtogroup Digital Key Device Application
* @{
********************************************************************************** */
/*! *********************************************************************************
* \file app_digital_key_device.c
*
* Copyright 2021 NXP
*
* NXP Confidential Proprietary
*
* No part of this document must be reproduced in any form - including copied,
* transcribed, printed or by any electronic means - without specific written
* permission from NXP.
********************************************************************************** */

/************************************************************************************
*************************************************************************************
* Include
*************************************************************************************
************************************************************************************/
/* Framework / Drivers */
#include "app_preinclude.h"
#include "app_preinclude_common.h"
#include "EmbeddedTypes.h"
#include "Keyboard.h"
#include "LED.h"
#include "Panic.h"
#include "TimersManager.h"
#include "FunctionLib.h"
#include "MemManager.h"
#include "Reset.h"
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
#include "shell.h"
#endif
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
#include "PWR_Interface.h"
#include "PWR_Configuration.h"
#endif

/* BLE Host Stack */
#include "gatt_server_interface.h"
#include "gatt_client_interface.h"
#include "gap_interface.h"
#include "gatt_db_app_interface.h"
#include "l2ca_cb_interface.h"
#include "gatt_db_handles.h"

/* Profile / Services */
#include "digital_key_interface.h"

#include "ble_conn_manager.h"
#include "ble_service_discovery.h"

#include "ApplMain.h"
#include "app_digital_key_device.h"
#include "shell_digital_key_device.h"

#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
#include "Ranger4UciCmd.h"
#include "Ranger4_demo_task.h"
#endif
/************************************************************************************
*************************************************************************************
* Private macros
*************************************************************************************
************************************************************************************/
#define mcEncryptionKeySize_c   16
/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
************************************************************************************/
appPeerInfo_t maPeerInformation[gAppMaxConnections_c];
gattCharacteristic_t maCharacteristics[mcNumCharacteristics_c]; /* Index 0 - Vehicle PSM */
uint16_t mValVehiclePsm;

/* Which peer are we doing OOB pairing with? */
deviceId_t mCurrentPeerId = gInvalidDeviceId_c;

#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))

/* Pairing process needed */
bool_t mIsPairingProcess = FALSE;
extern SessionManagement_t UwbSessions;
extern UwbCapabilityManagement_t UwbCapability;
#endif
/************************************************************************************
*************************************************************************************
* Private type definitions
*************************************************************************************
************************************************************************************/

/************************************************************************************
*************************************************************************************
* Private memory declarations
*************************************************************************************
************************************************************************************/
#if defined(gAppUseBonding_d) && (gAppUseBonding_d)
static bool_t mRestoringBondedLink = FALSE;
#endif

#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1) 
/* LTK */
static uint8_t gaAppSmpLtk[gcSmpMaxLtkSize_c];

/* RAND*/
static uint8_t gaAppSmpRand[gcSmpMaxRandSize_c];

/* IRK */
static uint8_t gaAppSmpIrk[gcSmpIrkSize_c];

/* Address */
static uint8_t gaAppAddress[gcBleDeviceAddressSize_c];
static gapSmpKeys_t gAppOutKeys = {
    .cLtkSize = mcEncryptionKeySize_c,
    .aLtk = (void *)gaAppSmpLtk,
    .aIrk = (void *)gaAppSmpIrk,
    .aCsrk = NULL,
    .aRand = (void *)gaAppSmpRand,
    .cRandSize = gcSmpMaxRandSize_c,
    .ediv = 0,
    .addressType = 0,
    .aAddress = gaAppAddress
};
static gapSmpKeyFlags_t gAppOutKeyFlags;
static bool_t gAppOutLeSc;
static bool_t gAppOutAuth;
#endif

static uint8_t maOutCharReadBuffer[mCharReadBufferLength_c];
static uint16_t mOutCharReadByteCount;

/* Own address used during discovery. Included in First Approach Response. */
static uint8_t gaAppOwnDiscAddress[gcBleDeviceAddressSize_c];

/* Time Sync UWB Device Time. Demo value. */
static uint64_t mTsUwbDeviceTime = 0U;
/* 
Global used to identify if bond whas added by
shell command or connection with the device 
mBondAddedFromShell = FALSE bond created by connection
mBondAddedFromShell = TRUE  bond added by shell command
*/
static bool_t mBondAddedFromShell = FALSE;
/************************************************************************************
*************************************************************************************
* Private functions prototypes
*************************************************************************************
************************************************************************************/
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)  
static void BleApp_Disconnect(void);
static void BleApp_SetBondingData(appEventData_t *pEventData);
static void BleApp_RemoveBondingData(appEventData_t *pEventData);
static void AppPrintLePhyEvent(gapPhyEvent_t* pPhyEvent);
static void PrintLePhyEvent(void(*pfPrint)(const char *pBuff),gapPhyEvent_t* pPhyEvent);
static void BleApp_ListBondingData(void);
#endif


/* CCC SubEvents */
static bleResult_t CCC_SendSubEvent(deviceId_t deviceId,
                                    dkSubEventCategory_t category,
                                    dkSubEventCommandCompleteType_t type);

/* CCC Phase 2 */
static bleResult_t CCCPhase2_SendSPAKEResponse(deviceId_t deviceId, uint8_t *pData, uint16_t dataLen);
static bleResult_t CCCPhase2_SendSPAKEVerify(deviceId_t deviceId, uint8_t *pData, uint16_t dataLen);

static bleResult_t CCC_FirstApproachReq
(
    deviceId_t deviceId,
    uint8_t* pBdAddr,
    gapLeScOobData_t* pOobData
);

static void App_HandleKeys(appEventData_t *pEventData);
static void App_HandleGattClientCallback(appEventData_t *pEventData);
static void App_HandleGenericCallback(appEventData_t *pEventData);
static void App_HandleConnectionCallback(appEventData_t *pEventData);
static void App_HandleL2capPsmDataCallback(appEventData_t *pEventData);
static void App_HandleL2capPsmControlCallback(appEventData_t *pEventData);
static bleResult_t SetBondingData(uint8_t nvmIndex, bleAddressType_t addressType,
                                  uint8_t* ltk, uint8_t* irk, uint8_t* address);

static void BleApp_HandleIdleState(deviceId_t peerDeviceId, appEvent_t event);
static void BleApp_HandleServiceDiscState(deviceId_t peerDeviceId, appEvent_t event);
static void BleApp_HandlePairState(deviceId_t peerDeviceId, appEvent_t event);

/************************************************************************************
*************************************************************************************
* Public functions
*************************************************************************************
************************************************************************************/
extern uint16_t PWRLib_BLL_GetInstantTimer(void);
/*! *********************************************************************************
* \brief        State machine handler of the Digital Key Device application.
*
* \param[in]    peerDeviceId        Peer device ID.
* \param[in]    event               Event type.
********************************************************************************** */
void BleApp_StateMachineHandler(deviceId_t peerDeviceId, appEvent_t event)
{
    switch (maPeerInformation[peerDeviceId].appState)
    {
        case mAppIdle_c:
        {
            BleApp_HandleIdleState(peerDeviceId, event);
        }
        break;

        case mAppExchangeMtu_c:
        {
        	shell_write("\r\nmAppExchangeMtu_c event =");
			shell_writeDec(event);

            if (event == mAppEvt_GattProcComplete_c)
            {
                bleUuid_t dkServiceUuid;

                /* Moving to Service Discovery State */
                maPeerInformation[peerDeviceId].appState = mAppServiceDisc_c;
#if ((defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U)) && (RECEIVE_RANGING_RESULT_FROM_VEHICLE == 1))
                BleServDisc_Start(peerDeviceId);
#else
                /* Start Service Discovery */
                dkServiceUuid.uuid16 = gBleSig_CCC_DK_UUID_d;
                (void)BleServDisc_FindService(peerDeviceId, gBleUuidType16_c, &dkServiceUuid);
#endif
            }
            else
            {
                if (event == mAppEvt_GattProcError_c)
                {
                    (void)Gap_Disconnect(peerDeviceId);
                }
            }
        }
        break;

        case mAppServiceDisc_c:
        {
            BleApp_HandleServiceDiscState(peerDeviceId, event);
        }
        break;

        case mAppRunning_c:
        {
            if ( event == mAppEvt_PeerDisconnected_c )
            {
                maPeerInformation[peerDeviceId].deviceId = gInvalidDeviceId_c;
                maPeerInformation[peerDeviceId].appState = mAppIdle_c;
                shell_cmd_finished();
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))                
//                Ranger4UciCmd_MacSessionStopRanging(UwbSessions.UwbSessionID);
                Ranger4UciCmd_MacSessionCfgDeInit(UwbSessions.UwbSessionID);
#endif
            }
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
            else if ( event == mAppEvt_UwbRcvUrskCreateReq )
            {
                /* URSK Derivation */
                /* Dummy data - replace with calls to get actual data */        
                uint16_t payloadLen = gDummyPayloadLength_c;
                uint8_t payload[gDummyPayloadLength_c] = {'C','r','e','a','t','-','U','R','S','K','-','R','S','P',' ',' '};
                (void)CCC_CreatRangingKey(peerDeviceId, payload, payloadLen);
            }
            else if( event == mAppEvt_UwbRcvRCRQ )
            {
                if(mIsPairingProcess)
                {   
                    mIsPairingProcess = false;
                    (void)CCC_SendTimeSync(peerDeviceId, 
                                           &maPeerInformation[peerDeviceId].TsLocalDeviceEventCount, 
                                           &maPeerInformation[peerDeviceId].TsUwbLocalDeviceTime, 
                                           1U);                    
                }
            }
            else if (event == mAppEvt_UwbRcvRSRQ)
            {
#if RECEIVE_RANGING_RESULT_FROM_VEHICLE
                BleApp_ConfigureNotifications(peerDeviceId);
#endif
                Ranger4UciCmd_MacSessionCfgInit(UwbSessions.UwbSessionID, UwbSessions.SessionType);

            }
            else if(event == mAppEvt_UwbRcvRSSRQ)
            {
//                Ranger4UciCmd_MacSessionConfigure(UwbSessions.UwbSessionID, 
//                                                  UwbSessions.SessionSetCfgSize, 
//                                                  UwbSessions.pSessionCfg);                
                QueryUwbTimeStamp(peerDeviceId | 0xF0);
            }
#endif

        }
        break;

        case mAppCCCPhase2WaitingForRequest_c:
        {
            if (event == mAppEvt_SentSPAKEResponse_c)
            {
               maPeerInformation[peerDeviceId].appState = mAppCCCPhase2WaitingForVerify_c;
            }
        }
        break;

        case mAppCCCPhase2WaitingForVerify_c:
        {
            if (event == mAppEvt_ReceivedSPAKEVerify_c)
            {
                maPeerInformation[peerDeviceId].appState = mAppCCCWaitingForPairingReady_c;
            }
        }
        break;

        case mAppCCCWaitingForPairingReady_c:
        {
            if (event == mAppEvt_ReceivedPairingReady_c)
            {
                mCurrentPeerId = peerDeviceId;
                (void)Gap_LeScGetLocalOobData();
                maPeerInformation[peerDeviceId].appState = mAppPair;
            }
        }
        break;
        
        case mAppPair:
        {
            BleApp_HandlePairState(peerDeviceId, event);
        }
        break;

        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*!*************************************************************************************************
 \fn     uint8_t APP_BleEventHandler(void *pData)
 \brief  This function is used to handle events from BLE

 \param  [in]   pData - pointer to data;
 ***************************************************************************************************/
void APP_BleEventHandler(void *pData)
{
    appEventData_t *pEventData = (appEventData_t *)pData;
    
    switch(pEventData->appEvent)
    {
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
        case mAppEvt_Shell_Reset_Command_c:
        {
            ResetMCU();
        }
        break;

        case mAppEvt_Shell_FactoryReset_Command_c:
        {
            (void)BleApp_FactoryReset();
        }
        break;
        
        case mAppEvt_Shell_ShellStartDiscovery_Command_c:
        {
            BleApp_Start();
        }
        break;
        
        case mAppEvt_Shell_StopDiscovery_Command_c:
        {
            (void)Gap_StopScanning();
        }
        break;

        case mAppEvt_Shell_Disconnect_Command_c:
        {
            BleApp_Disconnect();
        }
        break;
        
        case mAppEvt_Shell_SetBondingData_Command_c:
        {
            BleApp_SetBondingData(pEventData);
        }
        break;
        
        case mAppEvt_Shell_ListBondedDev_Command_c:
        {
            BleApp_ListBondingData();
        }
        break;
        
        case mAppEvt_Shell_RemoveBondedDev_Command_c:
        {
            BleApp_RemoveBondingData(pEventData);
        }
        break;
#endif

        case mAppEvt_KBD_EventPressPB1_c:
        case mAppEvt_KBD_EventLongPB1_c:
        case mAppEvt_KBD_EventVeryLongPB1_c:
        {
            App_HandleKeys(pEventData);
            break;
        }

        case mAppEvt_GattClientCallback_GattProcError_c:
        case mAppEvt_GattClientCallback_GattProcReadCharacteristicValue_c:
        case mAppEvt_GattClientCallback_GattProcReadUsingCharacteristicUuid_c:
        case mAppEvt_GattClientCallback_GattProcComplete_c:
        {
            App_HandleGattClientCallback(pEventData);
            break;
        }

        case mAppEvt_ServiceDiscoveryCallback_DiscoveryFinishedWithSuccess_c:
        {
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_ServiceDiscoveryComplete_c);
            break;
        }

        case mAppEvt_ServiceDiscoveryCallback_DiscoveryFinishedFailed_c:
        {
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_ServiceDiscoveryFailed_c);
            break;
        }

        case mAppEvt_GenericCallback_PeerDisconnected_c:
        {
            /* Factory reset may trigger internal error in some scenarios. */
            BleApp_StateMachineHandler( mCurrentPeerId, mAppEvt_PeerDisconnected_c );
            break;
        }

        case mAppEvt_GenericCallback_LePhyEvent_c:
        case mAppEvt_GenericCallback_LeScLocalOobData_c:
        case mAppEvt_GenericCallback_RandomAddressReady_c:
        case mAppEvt_GenericCallback_CtrlNotifEvent_c:
    	case mAppEvt_GenericCallback_BondCreatedEvent_c:
        {
            App_HandleGenericCallback(pEventData);
            break;
        }

        case mAppEvt_ConnectionCallback_ConnEvtConnected_c:
        case mAppEvt_ConnectionCallback_ConnEvtDisconnected_c:
        case mAppEvt_ConnectionCallback_ConnEvtLeScOobDataRequest_c:
        case mAppEvt_ConnectionCallback_ConnEvtPairingComplete_c:
        case mAppEvt_ConnectionCallback_ConnEvtEncryptionChanged_c:
        case mAppEvt_ConnectionCallback_ConnEvtAuthenticationRejected_c:
        {
            App_HandleConnectionCallback(pEventData);
            break;
        }

        case mAppEvt_L2capPsmDataCallback_c:
        {
            App_HandleL2capPsmDataCallback(pEventData);
            break;
        }

        case mAppEvt_L2capPsmControlCallback_LePsmConnectionComplete_c:
        case mAppEvt_L2capPsmControlCallback_LePsmDisconnectNotification_c:
        case mAppEvt_L2capPsmControlCallback_NoPeerCredits_c:
        {
            App_HandleL2capPsmControlCallback(pEventData);
            break;
        }

        default:
        {
            ; /* No action required */
        }
        break;
    }
    
    /* Free Buffer */
    (void)MEM_BufferFree(pData);
    pData = NULL;
    
}


/************************************************************************************
*************************************************************************************
* Private functions
*************************************************************************************
************************************************************************************/

/*! *********************************************************************************
* \brief        Handler of the mAppIdle_c state for BleApp_StateMachineHandler.
*
* \param[in]    peerDeviceId        Peer device ID.
* \param[in]    event               Event type.
************************************************************************************/
static void BleApp_HandleIdleState(deviceId_t peerDeviceId, appEvent_t event)
{
    if (event == mAppEvt_PeerConnected_c)
    {
        if (maPeerInformation[peerDeviceId].customInfo.hPsmChannelChar == gGattDbInvalidHandle_d)
        {
            /* Moving to Exchange MTU State */
            maPeerInformation[peerDeviceId].appState = mAppExchangeMtu_c;
            bleResult_t ret = GattClient_ExchangeMtu(peerDeviceId, gAttMaxMtu_c);
            shell_write("\r\nGattClient_ExchangeMtu ret =");
            shell_writeDec(ret);
        }
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))        
        maPeerInformation[peerDeviceId].IsPsmChannelCreated = false;
#endif
    }
    else if ( event == mAppEvt_EncryptionChanged_c )
    {
        bleUuid_t psmCharUuid;
        gattHandleRange_t handleRange;
        
        /* Moving to Service Discovery State*/
        maPeerInformation[peerDeviceId].appState = mAppServiceDisc_c;
        
        /* Read SPSM from vehicle. */
        FLib_MemCpy(psmCharUuid.uuid128, uuid_char_vehicle_psm, gcBleLongUuidSize_c);
        handleRange.startHandle = 0x0001U;
        handleRange.endHandle = 0xFFFFU;
        (void)GattClient_ReadUsingCharacteristicUuid(peerDeviceId,
                                                     gBleUuidType128_c,
                                                     &psmCharUuid,
                                                     &handleRange,
                                                     maOutCharReadBuffer,
                                                     mCharReadBufferLength_c,
                                                     &mOutCharReadByteCount);
    }
    else if ( event == mAppEvt_AuthenticationRejected_c )
    {
        /* Something went wrong - peer has likely lost the bond.
           Must pair again, move to Exchange MTU */
        maPeerInformation[peerDeviceId].appState = mAppExchangeMtu_c;
        maPeerInformation[peerDeviceId].isBonded = FALSE;
        (void)GattClient_ExchangeMtu(peerDeviceId, gAttMaxMtu_c);
    }
    else
    {
        /* For MISRA compliance */
    }
}

/*! *********************************************************************************
* \brief        Handler of the mAppServiceDisc_c state for BleApp_StateMachineHandler.            
*
* \param[in]    peerDeviceId        Peer device ID.
* \param[in]    event               Event type.
************************************************************************************/
static void BleApp_HandleServiceDiscState(deviceId_t peerDeviceId, appEvent_t event)
{
    if (event == mAppEvt_ReadCharacteristicValueComplete_c)
    {
        (void)L2ca_ConnectLePsm(*(uint8_t*)maCharacteristics[mcCharVehiclePsmIndex_c].value.paValue,
                                peerDeviceId, mAppLeCbInitialCredits_c);
    }

    if (event == mAppEvt_PsmChannelCreated_c)
    {
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))        
        maPeerInformation[peerDeviceId].IsPsmChannelCreated = true;
#endif        
        if (maPeerInformation[peerDeviceId].isBonded)
        {
            /* Send Time Sync */
            (void)CCC_SendTimeSync(peerDeviceId, 
                                   &maPeerInformation[peerDeviceId].TsLocalDeviceEventCount, 
                                   &maPeerInformation[peerDeviceId].TsUwbLocalDeviceTime, 
                                   1U);
            maPeerInformation[peerDeviceId].appState = mAppRunning_c;
            /* Update connection interval to CCC recommended value */
            (void)Gap_UpdateConnectionParameters(peerDeviceId,
                                                 gcConnectionIntervalCCC_c,
                                                 gcConnectionIntervalCCC_c,
                                                 gConnReqParams.connLatency,
                                                 gConnReqParams.supervisionTimeout,
                                                 gConnReqParams.connEventLengthMin,
                                                 gConnReqParams.connEventLengthMax);
             shell_cmd_finished();
        }
        else
        {
            bleResult_t status = gBleUnexpectedError_c;
            /* Send request_owner_pairing */
            shell_write("\r\nSending Command Complete SubEvent: Request_owner_pairing\r\n");
            status =  CCC_SendSubEvent(peerDeviceId, gCommandComplete_c, gRequestOwnerPairing_c);
            if (status == gBleSuccess_c)
            {
                maPeerInformation[peerDeviceId].appState = mAppCCCPhase2WaitingForRequest_c;
            }
        }
    }
}

/*! *********************************************************************************
* \brief        Handler of the mAppPair state for BleApp_StateMachineHandler.
*
* \param[in]    peerDeviceId        Peer device ID.
* \param[in]    event               Event type.
************************************************************************************/
static void BleApp_HandlePairState(deviceId_t peerDeviceId, appEvent_t event)
{
    if ( event == mAppEvt_PairingLocalOobData_c )
    {
        shell_write("\r\nSending First_Approach_RQ\r\n");
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))        
        mIsPairingProcess = true;
#endif
        (void)CCC_FirstApproachReq(peerDeviceId, gaAppOwnDiscAddress, &maPeerInformation[peerDeviceId].oobData);
    }
    else if ( event == mAppEvt_PairingPeerOobDataRcv_c )
    {
        shell_write("\r\nReceived First_Approach_RS.\r\n");
        shell_write("\r\nPairing...\r\n");
        (void)Gap_Pair(peerDeviceId, &gPairingParameters);
    }
    else if ( event == mAppEvt_PairingPeerOobDataReq_c )
    {
        (void)Gap_LeScSetPeerOobData(peerDeviceId, &maPeerInformation[peerDeviceId].peerOobData);
    }
    else if ( event == mAppEvt_PairingComplete_c )
    {
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
#else        
        uint64_t devEvtCnt = 0U;
#endif
        FLib_MemSet(&maPeerInformation[peerDeviceId].oobData, 0x00, sizeof(gapLeScOobData_t));
        FLib_MemSet(&maPeerInformation[peerDeviceId].peerOobData, 0x00, sizeof(gapLeScOobData_t));
        maPeerInformation[peerDeviceId].appState = mAppRunning_c;
        shell_write("\r\nPairing successful.\r\n");
        shell_cmd_finished();
        
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
        /* The Time Sync will be sent after exchange uwb capability, not in here*/
#else        
        /* Send Time Sync */
        (void)CCC_SendTimeSync(peerDeviceId, &devEvtCnt, &mTsUwbDeviceTime, 1U);
#endif
#if defined(gAppUseBonding_d) && (gAppUseBonding_d)
                /* Write data in NVM */
                (void)Gap_SaveCustomPeerInformation(peerDeviceId,
                                                    (void *)&maPeerInformation[peerDeviceId].customInfo, 0,
                                                    (uint16_t)sizeof(appCustomInfo_t));
#endif
        /* Update connection interval to CCC recommended value */
        (void)Gap_UpdateConnectionParameters(peerDeviceId,
                                             gcConnectionIntervalCCC_c,
                                             gcConnectionIntervalCCC_c,
                                             gConnReqParams.connLatency,
                                             gConnReqParams.supervisionTimeout,
                                             gConnReqParams.connEventLengthMin,
                                             gConnReqParams.connEventLengthMax);
    }
    else
    {
        /* For MISRA compliance */
    }    
}

/*! *********************************************************************************
* \brief        Handles L2capPsmControl events.
*
* \param[in]    pEventData    pointer to appEventData_t.
********************************************************************************** */
static void App_HandleL2capPsmControlCallback(appEventData_t *pEventData)
{
    switch(pEventData->appEvent)
    {
        case mAppEvt_L2capPsmControlCallback_LePsmConnectionComplete_c:
        {
            l2caLeCbConnectionComplete_t *pConnComplete = pEventData->eventData.pData;

            if (pConnComplete->result == gSuccessful_c)
            {
                /* Handle Conn Complete */
                shell_write("\r\nL2CAP PSM Connection Complete.\r\n");

                maPeerInformation[pConnComplete->deviceId].customInfo.psmChannelId = pConnComplete->cId;
                /* Move to Time Sync */
                BleApp_StateMachineHandler(maPeerInformation[pConnComplete->deviceId].deviceId, mAppEvt_PsmChannelCreated_c);
            }
            break;
        }

        case mAppEvt_L2capPsmControlCallback_LePsmDisconnectNotification_c:
        {
            shell_write("\r\nL2CAP PSM disconnected. Reconnecting...\r\n");
            (void)L2ca_ConnectLePsm(*(uint8_t*)maCharacteristics[mcCharVehiclePsmIndex_c].value.paValue,
                                        pEventData->eventData.peerDeviceId, mAppLeCbInitialCredits_c);
            break;
        }

        case mAppEvt_L2capPsmControlCallback_NoPeerCredits_c:
        {
            l2caLeCbNoPeerCredits_t *pCbNoPeerCredits = pEventData->eventData.pData;
            
            (void)L2ca_SendLeCredit (pCbNoPeerCredits->deviceId,
                               pCbNoPeerCredits->cId,
                               mAppLeCbInitialCredits_c);
            break;
        }

        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*! *********************************************************************************
* \brief        Handles keyboard events.
*
* \param[in]    pEventData    pointer to appEventData_t.
********************************************************************************** */
static void App_HandleKeys(appEventData_t *pEventData)
{
    switch(pEventData->appEvent)
    {
        case mAppEvt_KBD_EventPressPB1_c:
        {
            BleApp_Start();
            break;
        }
        
        case mAppEvt_KBD_EventLongPB1_c:
        {
            uint8_t mPeerId = 0;
            for (mPeerId = 0; mPeerId < (uint8_t)gAppMaxConnections_c; mPeerId++)
            {
                if (maPeerInformation[mPeerId].deviceId != gInvalidDeviceId_c)
                {
                    (void)Gap_Disconnect(maPeerInformation[mPeerId].deviceId);
                }
            }
            break;
        }
        

        case mAppEvt_KBD_EventVeryLongPB1_c:
        {
            (void)BleApp_FactoryReset();
            break;
        }

        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*! *********************************************************************************
* \brief        Handles GattClientCallback events.
*
* \param[in]    pEventData    pointer to appEventData_t.
********************************************************************************** */
static void App_HandleGattClientCallback(appEventData_t *pEventData)
{
    switch(pEventData->appEvent)
    {

        case mAppEvt_GattClientCallback_GattProcError_c:
        {
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_GattProcError_c);
            break;
        }

        case mAppEvt_GattClientCallback_GattProcReadCharacteristicValue_c:
        {
            maPeerInformation[pEventData->eventData.peerDeviceId].customInfo.lePsmValue = mValVehiclePsm;
            /* Register DK L2CAP PSM */
            (void)L2ca_RegisterLePsm(maPeerInformation[pEventData->eventData.peerDeviceId].customInfo.lePsmValue, gDKMessageMaxLength_c);
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_ReadCharacteristicValueComplete_c);
            break;
        }

        case mAppEvt_GattClientCallback_GattProcReadUsingCharacteristicUuid_c:
        {
            maCharacteristics[mcCharVehiclePsmIndex_c].value.paValue = (uint8_t *)&mValVehiclePsm;
            /* length 1 octet, handle 2 octets, value(psm) 2 octets */
            maCharacteristics[mcCharVehiclePsmIndex_c].value.handle = (((uint16_t)maOutCharReadBuffer[2]) << 8) | (uint16_t)maOutCharReadBuffer[1];
            maCharacteristics[mcCharVehiclePsmIndex_c].value.paValue[0] = maOutCharReadBuffer[3];
            maCharacteristics[mcCharVehiclePsmIndex_c].value.paValue[1] = maOutCharReadBuffer[4];
            maPeerInformation[pEventData->eventData.peerDeviceId].customInfo.lePsmValue = mValVehiclePsm;
            /* Register DK L2CAP PSM */
            (void)L2ca_RegisterLePsm(maPeerInformation[pEventData->eventData.peerDeviceId].customInfo.lePsmValue, gDKMessageMaxLength_c);
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_ReadCharacteristicValueComplete_c);
            break;
        }

        case mAppEvt_GattClientCallback_GattProcComplete_c:
        {
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_GattProcComplete_c);
            break;
        }

        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*! *********************************************************************************
* \brief        Handles GenericCallback events.
*
* \param[in]    pEventData    pointer to appEventData_t.
********************************************************************************** */
static void App_HandleGenericCallback(appEventData_t *pEventData)
{
    switch(pEventData->appEvent)
    {

        case mAppEvt_GenericCallback_PeerDisconnected_c:
        {
            /* Factory reset may trigger internal error in some scenarios. */
            BleApp_StateMachineHandler( mCurrentPeerId, mAppEvt_PeerDisconnected_c );
            break;
        }
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
        case mAppEvt_GenericCallback_LePhyEvent_c:
        {
            gapPhyEvent_t *pPhyEvent = (gapPhyEvent_t *)pEventData->eventData.pData;
            if(pPhyEvent->phyEventType == gPhyUpdateComplete_c )
            {
                AppPrintLePhyEvent(pPhyEvent);
            }

            pPhyEvent = NULL;
            break;
        }
#endif

        case mAppEvt_GenericCallback_LeScLocalOobData_c:
        {
            if (mCurrentPeerId != gInvalidDeviceId_c)
            {
                FLib_MemCpy(&maPeerInformation[mCurrentPeerId].oobData, pEventData->eventData.pData, sizeof(gapLeScOobData_t));
                BleApp_StateMachineHandler(mCurrentPeerId, mAppEvt_PairingLocalOobData_c);
            }
            break;
        }

        case mAppEvt_GenericCallback_RandomAddressReady_c:
        {
            FLib_MemCpy(gaAppOwnDiscAddress, pEventData->eventData.pData, gcBleDeviceAddressSize_c);
            break;
        }

        case mAppEvt_GenericCallback_CtrlNotifEvent_c:
        {
            bleNotificationEvent_t *pCtrlNotifEvent = (bleNotificationEvent_t *)pEventData->eventData.pData;
            
            if ((pCtrlNotifEvent->eventType & ((uint16_t)gNotifConnCreated_c | (uint16_t)gNotifPhyUpdateInd_c)) > 0U )
            {
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
                /* Compute event timestamp. */
                uint16_t bleTime = 0U;

                /* Subtract event delay */
                bleTime = PWRLib_BLL_GetInstantTimer();
                
                maPeerInformation[pCtrlNotifEvent->deviceId].TsLocalDeviceEventCount = pCtrlNotifEvent->ce_counter;
                
                if (bleTime >= pCtrlNotifEvent->timestamp)
                {
                    maPeerInformation[pCtrlNotifEvent->deviceId].TsBleEvtDelay= ((uint32_t)bleTime - (uint32_t)pCtrlNotifEvent->timestamp) * 625U;
                }
                else
                {
                    maPeerInformation[pCtrlNotifEvent->deviceId].TsBleEvtDelay = ((0x0000FFFFU - (uint32_t)pCtrlNotifEvent->timestamp) + bleTime) * 625U;
                }
                
                if ((pCtrlNotifEvent->eventType & (uint16_t)gNotifPhyUpdateInd_c) > 0U)
                {
                    maPeerInformation[pCtrlNotifEvent->deviceId].NeedsSendTimeSyncForPhyUpdate = true;
                }
                /* record peer device id that needs time sync */        
                QueryUwbTimeStamp(pCtrlNotifEvent->deviceId );
#else
                /* Compute event timestamp. */
                uint16_t bleTime = 0U;
                /* Get current timestamp */
                mTsUwbDeviceTime = TMR_GetTimestamp();
                /* Subtract event delay */
                bleTime = PWRLib_BLL_GetInstantTimer();
                if (bleTime >= pCtrlNotifEvent->timestamp)
                {
                    mTsUwbDeviceTime = mTsUwbDeviceTime - ((uint64_t)bleTime - (uint64_t)pCtrlNotifEvent->timestamp) * 625U;
                }
                else
                {
                    mTsUwbDeviceTime = mTsUwbDeviceTime - ((0x000000000000FFFFU - (uint64_t)pCtrlNotifEvent->timestamp) + bleTime) * 625U;
                }

                if ((pCtrlNotifEvent->eventType & (uint16_t)gNotifPhyUpdateInd_c) > 0U)
                {
                    /* Send Time Sync. */
                    uint64_t devEvtCnt = 0xFFFFFFFFFFFFFFFFU;
                    
                    if (maPeerInformation[pCtrlNotifEvent->deviceId].appState == mAppRunning_c)
                    {
                        (void)CCC_SendTimeSync(pCtrlNotifEvent->deviceId, &devEvtCnt, &mTsUwbDeviceTime, 1U);
                    }
                }
#endif
            }
            break;
        }
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)        
        case mAppEvt_GenericCallback_BondCreatedEvent_c:
        {
            bleBondCreatedEvent_t *pBondEventData = (bleBondCreatedEvent_t *)pEventData->eventData.pData;
            bleResult_t status;
            
            status = Gap_LoadKeys(pBondEventData->nvmIndex,
                                  &gAppOutKeys, &gAppOutKeyFlags, &gAppOutLeSc,
                                  &gAppOutAuth);
            
            if ( status == gBleSuccess_c)
            {
                /* address type, address, ltk, irk */
                shell_write("\r\nBondingData: ");
                shell_writeHex((uint8_t*)&gAppOutKeys.addressType, 1);
                shell_write(" ");
                shell_writeHex(gAppOutKeys.aAddress, 6);
                shell_write(" ");
                shell_writeHex((uint8_t*)gAppOutKeys.aLtk, 16);
                shell_write(" ");
                shell_writeHex((uint8_t*)gAppOutKeys.aIrk, 16);
                shell_write("\r\n");
            }
            
            if (mBondAddedFromShell == TRUE)
            {
                shell_cmd_finished();
                mBondAddedFromShell = FALSE;
                gPrivacyStateChangedByUser = TRUE;
                (void)BleConnManager_DisablePrivacy();
            }
            break;
        }
#endif        
        default:
        {
            ; /* No action required */
        }
        break;
    }

}

/*! *********************************************************************************
* \brief        Handles ConnectionCallback events.
*
* \param[in]    pEventData    pointer to appEventData_t.
********************************************************************************** */
static void App_HandleConnectionCallback(appEventData_t *pEventData)
{
    switch(pEventData->appEvent)
    {
        case mAppEvt_ConnectionCallback_ConnEvtConnected_c:
        {
            appConnectionCallbackEventData_t *pConnectedEventData = (appConnectionCallbackEventData_t *)pEventData->eventData.pData;
            
            /* Check MISRA directive 4.14 */
            if(pConnectedEventData->peerDeviceId >= gAppMaxConnections_c)
            {
                 /* peerDeviceId bigger then gAppMaxConnections_c */ 
                 panic(0, (uint32_t)App_HandleConnectionCallback, 0, 0);
            }
            
            /* Save address used during discovery if controller privacy was used. */
            if (pConnectedEventData->pConnectedEvent.localRpaUsed)
            {
                FLib_MemCpy(gaAppOwnDiscAddress, pConnectedEventData->pConnectedEvent.localRpa, gcBleDeviceAddressSize_c);
            }

            /* Update UI */
            LED_StopFlashingAllLeds();
            Led1On();

            shell_write("Connected!\r\n");

            maPeerInformation[pConnectedEventData->peerDeviceId].deviceId = pConnectedEventData->peerDeviceId;
            maPeerInformation[pConnectedEventData->peerDeviceId].isBonded = FALSE;

            /* Set low power mode */
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
            (void)PWR_ChangeDeepSleepMode(gAppDeepSleepMode_c);
            PWR_AllowDeviceToSleep();
#endif

#if defined(gAppUseBonding_d) && (gAppUseBonding_d)
            (void)Gap_CheckIfBonded(pConnectedEventData->peerDeviceId, &maPeerInformation[pConnectedEventData->peerDeviceId].isBonded, NULL);

            if ((maPeerInformation[pConnectedEventData->peerDeviceId].isBonded) &&
                (gBleSuccess_c == Gap_LoadCustomPeerInformation(pConnectedEventData->peerDeviceId,
                    (void*)&maPeerInformation[pConnectedEventData->peerDeviceId].customInfo, 0, (uint16_t)sizeof(appCustomInfo_t))))
            {
                mRestoringBondedLink = TRUE;
                /* Restored custom connection information. Encrypt link */
                (void)Gap_EncryptLink(pConnectedEventData->peerDeviceId);
                shell_write("send Gap_EncryptLink!\r\n");
            }
#endif
            BleApp_StateMachineHandler(pConnectedEventData->peerDeviceId, mAppEvt_PeerConnected_c);
            break;
        }

        case mAppEvt_ConnectionCallback_ConnEvtDisconnected_c:
        {
            /* Reset Service Discovery to be sure*/
            BleServDisc_Stop(pEventData->eventData.peerDeviceId);

            shell_write("Disconnected!\r\n");

#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
            /* Go to sleep */
            (void)PWR_ChangeDeepSleepMode(cPWR_DeepSleepMode);
            Led1Off();
#else
            LED_TurnOffAllLeds();
            LED_StartFlash(LED_ALL);
#endif
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_PeerDisconnected_c);
            break;
        }

        case mAppEvt_ConnectionCallback_ConnEvtLeScOobDataRequest_c:
        {
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_PairingPeerOobDataReq_c);
            break;
        }

        case mAppEvt_ConnectionCallback_ConnEvtPairingComplete_c:
        {
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_PairingComplete_c);
            break;
        }

        case mAppEvt_ConnectionCallback_ConnEvtEncryptionChanged_c:
        {
            if( mRestoringBondedLink )
            {
                mRestoringBondedLink = FALSE;
                BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_EncryptionChanged_c);
            }
            break;
        }

        case mAppEvt_ConnectionCallback_ConnEvtAuthenticationRejected_c:
        {
            BleApp_StateMachineHandler(pEventData->eventData.peerDeviceId, mAppEvt_AuthenticationRejected_c);
            break;
        }

        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*! *********************************************************************************
* \brief        Handles L2capPsmDataCallback events.
*
* \param[in]    pEventData    pointer to appEventData_t.
********************************************************************************** */
static void App_HandleL2capPsmDataCallback(appEventData_t *pEventData)
{
   
    appEventL2capPsmData_t *l2capDataEvent = (appEventL2capPsmData_t *)pEventData->eventData.pData;
    deviceId_t deviceId = l2capDataEvent->deviceId;
    uint16_t packetLength = l2capDataEvent->packetLength;
    uint8_t* pPacket = l2capDataEvent->pPacket;
    
    if (packetLength > (gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c))
    {
        dkMessageType_t protocol = (dkMessageType_t)pPacket[0];
        rangingMsgId_t msgId = (rangingMsgId_t)pPacket[1];
        uint16_t length = 0;
        FLib_MemCpyReverseOrder(&length, &pPacket[2], gLengthFieldSize_c);

        switch (protocol)
        {
            case gDKMessageTypeFrameworkMessage_c:
            {
                if (msgId == gDkApduRQ_c)
                {
                    if (maPeerInformation[deviceId].appState == mAppCCCPhase2WaitingForRequest_c)
                    {
                        shell_write("\r\nSPAKE Request received.\r\n");
                        bleResult_t result = CCCPhase2_SendSPAKEResponse(deviceId, &pPacket[4], length);
                        if (result == gBleSuccess_c)
                        {
                            BleApp_StateMachineHandler(deviceId, mAppEvt_SentSPAKEResponse_c);
                        }
                    }
                    else if (maPeerInformation[deviceId].appState == mAppCCCPhase2WaitingForVerify_c)
                    {
                        shell_write("\r\nSPAKE Verify received.\r\n");
                        bleResult_t result = CCCPhase2_SendSPAKEVerify(deviceId, &pPacket[4], length);
                        if (result == gBleSuccess_c)
                        {
                            BleApp_StateMachineHandler(deviceId, mAppEvt_ReceivedSPAKEVerify_c);
                        }
                    }
                    else
                    {
                        /* For MISRA compliance */
                    }
                }
            }
            break;
            
            case gDKMessageTypeSupplementaryServiceMessage_c:
            {
                if ( (msgId == gFirstApproachRQ_c) || (msgId == gFirstApproachRS_c ) )
                {
                    if ( packetLength == (gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c + gFirstApproachReqRspPayloadLength) )
                    {
                        uint8_t *pData = &pPacket[gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c];
                        
                        /* BD address not used. */
                        pData += gcBleDeviceAddressSize_c;
                        /* Confirm Value */
                        FLib_MemCpy(&maPeerInformation[deviceId].peerOobData.confirmValue, pData, gSmpLeScRandomConfirmValueSize_c);
                        pData += gSmpLeScRandomConfirmValueSize_c;
                        /* Random Value */
                        FLib_MemCpy(&maPeerInformation[deviceId].peerOobData.randomValue, pData, gSmpLeScRandomValueSize_c);
                        
                        
                        /* Send event to the application state machine. */
                        BleApp_StateMachineHandler(deviceId, mAppEvt_PairingPeerOobDataRcv_c);
                    }
                    else
                    {
                        shell_write("\r\nERROR: Invalid length for FirstApproach message.\r\n");
                    }
                }
            }
            break;

            case gDKMessageTypeDKEventNotification_c:
            {
                if ( msgId == gDkEventNotification_c )
                {
                    if ( packetLength == (gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c + gCommandCompleteSubEventPayloadLength_c) )
                    {
                        dkSubEventCategory_t category = (dkSubEventCategory_t)pPacket[gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c];
                        if ( category == gCommandComplete_c)
                        {
                            dkSubEventCommandCompleteType_t type = (dkSubEventCommandCompleteType_t)pPacket[gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c + sizeof(category)];
                            switch (type)
                            {
                                case gBlePairingReady_c:
                                {
                                    shell_write("\r\nReceived Command Complete SubEvent: BLE_pairing_ready\r\n");
                                    BleApp_StateMachineHandler(deviceId, mAppEvt_ReceivedPairingReady_c);
                                }
                                break;

                                default:
                                {
                                    ; /* For MISRA compliance */
                                }
                                break;
                            }
                        }
                    }
                }
            }
            break;
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
            case gDKMessageTypeSEMessage_c:
            {
                if(msgId == gDkApduRQ_c)
                {
                    shell_write("\r\nURSK create request received.\r\n");
                    
                    BleApp_StateMachineHandler(deviceId, mAppEvt_UwbRcvUrskCreateReq);
                }
            }
            break;
            
            case gDKMessageTypeUWBRangingServiceMessage_c:
            {
//                uint8_t *pData = &pPacket[gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c];
                switch (msgId)
                {
                    case gRangingCapabilityRQ_c:
                    {
                        shell_write("\r\nReceived UWB Ranging Service Message: RC-RQ.\r\n");
                        
                        /*In case received RC-RQ, we select UWB Protocol Version, config id 
                          and Pluse shape Combination which are from list of common supported
                          ones between device and vehicle.*/
                        CCC_ProcessRangingCapabilityReq(deviceId, pPacket);

                        CCC_SendRangingCapabilityRes(deviceId, UwbSessions.SelectedDkProtolVersion,
                                                     UwbSessions.SelectedUwbConfigId, UwbSessions.SelectedPulseShapeCombo);
                        
                        BleApp_StateMachineHandler(deviceId, mAppEvt_UwbRcvRCRQ);
                    }
                    break;
                    
                    case gRangingSessionRQ_c:
                    {
                        CCC_ProcessRangingSessionReq(deviceId, pPacket);
                        // It's a invalid ID if session ID is 0
                        if(UwbSessions.UwbSessionID != 0)
                        {
                            shell_write("\r\nReceived UWB Ranging Service Message: RS-RQ.\r\n");
                            
                            CCC_ProcessRangingSessionReq(deviceId, pPacket);
                            
                            CCC_SendRangingSessionRsp(deviceId, &UwbSessions);
                            
                            BleApp_StateMachineHandler(deviceId, mAppEvt_UwbRcvRSRQ);
//                        Ranger4UciCmd_MacSessionCfgInit(UwbSessions.UwbSessionID, UwbSessions.SessionType);
                        }
                        else
                        {
                            shell_write("\r\nReceived UWB Ranging Service Message: RS-RQ.\r\n");
                        }
                    }
                    break;
                    
                    case gRangingSessionSetup_RQ_c:
                    {
                        shell_write("\r\nReceived UWB Ranging Service Message: RSS-RQ.\r\n"); 
                        
                        CCC_ProcessRangingSessionSetupReq(deviceId, pPacket);
                        
                        BleApp_StateMachineHandler(deviceId, mAppEvt_UwbRcvRSSRQ);
                    }
                    break;
                    
                    default:
                    break;
                }
            }
            break;
#endif
            default:
            {
                ; /* For MISRA compliance */
            }
            break;
        }
    }
}

#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
/*! *********************************************************************************
* \brief    Set bonding data.
*
********************************************************************************** */
static void BleApp_SetBondingData(appEventData_t *pEventData)
{
    /* Set address type, LTK, IRK and pear device address  */
    appBondingData_t *pAppBondingData = (appBondingData_t *)pEventData->eventData.pData;

    bleResult_t status = gBleSuccess_c;
    status = SetBondingData(pAppBondingData->nvmIndex, pAppBondingData->addrType, pAppBondingData->aLtk,
                            pAppBondingData->aIrk, pAppBondingData->deviceAddr);
    if ( status != gBleSuccess_c )
    {
        shell_write("\r\nsetbd failed with status: ");
        shell_writeHex((uint8_t*)&status, 2);
        shell_write("\r\n");
        shell_cmd_finished();
    }
    else
    {
#if defined(gAppUseBonding_d) && (gAppUseBonding_d == 1)
       (void)Gap_AddDeviceToWhiteList(pAppBondingData->addrType, pAppBondingData->deviceAddr);
#endif
        mBondAddedFromShell = TRUE;
    }
}

/*! *********************************************************************************
* \brief    Remove bonding data.
*
********************************************************************************** */
static void BleApp_RemoveBondingData(appEventData_t *pEventData)
{
#if (defined(gAppUseBonding_d) && (gAppUseBonding_d == 1U))
    bleResult_t result = gGapSuccess_c;
    result = Gap_LoadKeys(pEventData->eventData.peerDeviceId, &gAppOutKeys, &gAppOutKeyFlags, &gAppOutLeSc, &gAppOutAuth);
    if(result == gBleSuccess_c)
    {
        if(gBleSuccess_c == Gap_RemoveDeviceFromWhiteList(gAppOutKeys.addressType, gAppOutKeys.aAddress))
        {
            /* Remove bond based on nvm index stored in eventData.peerDeviceId */
            if ((Gap_RemoveBond(pEventData->eventData.peerDeviceId) == gBleSuccess_c))
            {
                gcBondedDevices--;
                gPrivacyStateChangedByUser = TRUE;
                (void)BleConnManager_DisablePrivacy();
                shell_write("\r\nBond removed!\r\n");
                shell_cmd_finished();
            }
            else
            {
                shell_write("\r\nOperation failed!\r\n");
                shell_cmd_finished();
            }
        }
        else
        {
             shell_write("\r\nOperation failed!\r\n");
             shell_cmd_finished();
        }
    }
    else
    {
        shell_write("\r\nRemoved bond failed because unable to load the keys from the bond.\r\n");
        shell_cmd_finished();
    }
#endif
}

/*! *********************************************************************************
* \brief    List bonding data.
*
********************************************************************************** */
static void BleApp_ListBondingData(void)
{
    gapIdentityInformation_t aIdentity[gMaxBondedDevices_c];
    uint8_t nrBondedDevices = 0;
    uint8_t foundBondedDevices = 0;
    bleResult_t result = Gap_GetBondedDevicesIdentityInformation(aIdentity, gMaxBondedDevices_c, &nrBondedDevices);
    if (gBleSuccess_c == result && nrBondedDevices > 0U)
    {
        for (uint8_t i = 0; i < (uint8_t)gMaxBondedDevices_c; i++)
        {
            result = Gap_LoadKeys((uint8_t)i, &gAppOutKeys, &gAppOutKeyFlags, &gAppOutLeSc, &gAppOutAuth);
            if (gBleSuccess_c == result && nrBondedDevices > 0U)
            {
                /* address type, address, ltk, irk */
                shell_write("\r\nNVMIndex: ");
                shell_writeHex((uint8_t*)&i, 1);
                shell_write(" ");
                shell_write(" BondingData: ");
                shell_writeHex((uint8_t*)&gAppOutKeys.addressType, 1);
                shell_write(" ");
                shell_writeHex(gAppOutKeys.aAddress, 6);
                shell_write(" ");
                shell_writeHex((uint8_t*)gAppOutKeys.aLtk, 16);
                shell_write(" ");
                shell_writeHex((uint8_t*)gAppOutKeys.aIrk, 16);
                foundBondedDevices++;
            }
            if(foundBondedDevices == nrBondedDevices)
            {
                shell_write("\r\n");
                shell_cmd_finished();
                break;
            }
        }
    }
}

/*! *********************************************************************************
* \brief    Set Bonding Data on the BLE application.
*
********************************************************************************** */
static bleResult_t SetBondingData(uint8_t nvmIndex, bleAddressType_t addressType,
                                  uint8_t* ltk, uint8_t* irk, uint8_t* address)
{
    bleResult_t status;
    
    gAppOutKeys.addressType = addressType;
    FLib_MemCpy(gAppOutKeys.aAddress, address, gcBleDeviceAddressSize_c);
    FLib_MemCpy(gAppOutKeys.aLtk, ltk, gcSmpMaxLtkSize_c);
    FLib_MemCpy(gAppOutKeys.aIrk, irk, gcSmpIrkSize_c);

    status = Gap_SaveKeys(nvmIndex, &gAppOutKeys, TRUE, FALSE);
    
    return status;
}

/*! *********************************************************************************
* \brief    Disconnect received from the BLE application.
*
********************************************************************************** */
static void BleApp_Disconnect(void)
{
    uint8_t peerId;
    
    for (peerId = 0; peerId < (uint8_t)gAppMaxConnections_c; peerId++)
    {
        if (maPeerInformation[peerId].deviceId != gInvalidDeviceId_c)
        {
            (void)Gap_Disconnect(maPeerInformation[peerId].deviceId);
        }
    }
}

/*! *********************************************************************************
* \brief        Prints phy event.
*
********************************************************************************** */
static void AppPrintLePhyEvent(gapPhyEvent_t* pPhyEvent)
{
    PrintLePhyEvent(shell_write, pPhyEvent);
}

/*! *********************************************************************************
* \brief        Prints phy event.
*
********************************************************************************** */
static void PrintLePhyEvent(void(*pfPrint)(const char *pBuff),gapPhyEvent_t* pPhyEvent)
{
    /* String dictionary corresponding to gapLePhyMode_t */
    static const char* mLePhyModeStrings[] =
    {
        "Invalid\r\n",
        "1M\r\n",
        "2M\r\n",
        "Coded\r\n",
    };    
    uint8_t txPhy = ((gapLePhyMode_tag)(pPhyEvent->txPhy) <= gLePhyCoded_c) ? pPhyEvent->txPhy : 0U;
    uint8_t rxPhy = ((gapLePhyMode_tag)(pPhyEvent->rxPhy) <= gLePhyCoded_c) ? pPhyEvent->rxPhy : 0U;
    pfPrint("Phy Update Complete.\r\n");
    pfPrint("TxPhy ");
    pfPrint(mLePhyModeStrings[txPhy]);
    pfPrint("RxPhy ");
    pfPrint(mLePhyModeStrings[rxPhy]);
}
#endif

/*! *********************************************************************************
 * \brief        Owner Pairing Certificate Exchange - step 1, SPAKE2+ Response Command
 *
 ********************************************************************************** */
static bleResult_t CCCPhase2_SendSPAKEResponse(deviceId_t deviceId, uint8_t *pData, uint16_t dataLen)
{
    bleResult_t result = gBleSuccess_c;

    /* Dummy data - replace with calls to get actual data */
    uint16_t payloadLen = gDummyPayloadLength_c;
    uint8_t payload[gDummyPayloadLength_c] = gDummyPayload_c;

    result = DK_SendMessage(deviceId,
                            maPeerInformation[deviceId].customInfo.psmChannelId,
                            gDKMessageTypeFrameworkMessage_c,
                            gDkApduRS_c,
                            payloadLen,
                            payload);
    shell_write("\r\nSPAKE Response sent.\r\n");
    return result;
}

/*! *********************************************************************************
 * \brief        Owner Pairing Certificate Exchange - step 2, SPAKE2+ Verify Command
 *
 ********************************************************************************** */
static bleResult_t CCCPhase2_SendSPAKEVerify(deviceId_t deviceId, uint8_t *pData, uint16_t dataLen)
{
    bleResult_t result = gBleSuccess_c;

    /* Dummy data - replace with calls to get actual data */
    uint16_t payloadLen = gDummyPayloadLength_c;
    uint8_t payload[gDummyPayloadLength_c] = gDummyPayload_c;

    result = DK_SendMessage(deviceId,
                            maPeerInformation[deviceId].customInfo.psmChannelId,
                            gDKMessageTypeFrameworkMessage_c,
                            gDkApduRS_c,
                            payloadLen,
                            payload);
    shell_write("\r\nSPAKE Verify sent.\r\n");
    return result;
}

/*! *********************************************************************************
 * \brief        Sends DK SubEvents to Car Anchor.
 *
 ********************************************************************************** */
static bleResult_t CCC_SendSubEvent(deviceId_t deviceId,
                                    dkSubEventCategory_t category,
                                    dkSubEventCommandCompleteType_t type)
{
    bleResult_t result = gBleSuccess_c;

    uint8_t payload[gCommandCompleteSubEventPayloadLength_c] = {0}; /* SubEvent Category + SubEvent Type */
    payload[0] = (uint8_t)category;
    payload[1] = (uint8_t)type;

    result = DK_SendMessage(deviceId,
                            maPeerInformation[deviceId].customInfo.psmChannelId,
                            gDKMessageTypeDKEventNotification_c,
                            gDkEventNotification_c,
                            gCommandCompleteSubEventPayloadLength_c,
                            payload);

    return result;
}


/*! *********************************************************************************
 * \brief        First Approach messages enables BLE OOB Secure LE pairing for both owner and friend devices
 *
 ********************************************************************************** */
static bleResult_t CCC_FirstApproachReq(deviceId_t deviceId, uint8_t* pBdAddr, gapLeScOobData_t* pOobData)
{
    bleResult_t result = gBleSuccess_c;
    uint8_t aPayload[gFirstApproachReqRspPayloadLength] = {0}; 
    uint8_t *pData = aPayload;
    
    if (FLib_MemCmpToVal(pOobData, 0x00, sizeof(gapLeScOobData_t)))
    {
        result = gBleInvalidParameter_c;
    }
    else
    {
        FLib_MemCpy(pData, pBdAddr, gcBleDeviceAddressSize_c);
        pData += gcBleDeviceAddressSize_c;
        FLib_MemCpy(pData, pOobData->confirmValue, gSmpLeScRandomConfirmValueSize_c);
        pData += gSmpLeScRandomConfirmValueSize_c;
        FLib_MemCpy(pData, pOobData->randomValue, gSmpLeScRandomValueSize_c);
        
        shell_write("\r\nOOB Data: ");
        shell_write("\r\nAddress, Confirm, Random:");
        shell_write(" ");
        shell_writeHex(pBdAddr, gcBleDeviceAddressSize_c);
        shell_write(" ");
        shell_writeHex((uint8_t*)pOobData->confirmValue, gSmpLeScRandomConfirmValueSize_c);
        shell_write(" ");
        shell_writeHex((uint8_t*)pOobData->randomValue, gSmpLeScRandomValueSize_c);
        shell_write("\r\n");
        
        result = DK_SendMessage(deviceId,
                                maPeerInformation[deviceId].customInfo.psmChannelId,
                                gDKMessageTypeSupplementaryServiceMessage_c,
                                gFirstApproachRQ_c,
                                gFirstApproachReqRspPayloadLength,
                                aPayload);
    }
    
    return result;
}


#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
/*! *********************************************************************************
 * \brief        Device sends Time Sync to Car Anchor.
 *
 ********************************************************************************** */
bleResult_t CCC_SendTimeSync(deviceId_t deviceId,
                                    uint64_t *pDevEvtCnt,
                                    uint64_t *pUwbDevTime,
                                    uint8_t success)
{
    bleResult_t result = gBleSuccess_c;

    uint8_t payload[gTimeSyncPayloadLength_c] = {0};
    uint8_t *pPtr = payload;
    
    /* Add DeviceEventCount */
    FLib_MemCpy(pPtr, pDevEvtCnt, sizeof(uint64_t));
    pPtr += sizeof(uint64_t);
    /* Add UWB_Device_Time */
    FLib_MemCpy(pPtr, pUwbDevTime, sizeof(uint64_t));
    pPtr += sizeof(uint64_t);
    /* Skip UWB_Device_Time_Uncertainty */
    pPtr++;
    /* Skip UWB_Clock_Skew_Measurement_available */
    pPtr++;
    /* Skip Device_max_PPM */
    pPtr += sizeof(uint16_t);
    /* Add Success */
    *pPtr = success;
    /* Skip RetryDelay */
    pPtr += sizeof(uint16_t);
    
    result = DK_SendMessage(deviceId,
                            maPeerInformation[deviceId].customInfo.psmChannelId,
                            gDKMessageTypeSupplementaryServiceMessage_c,
                            gTimeSync_c,
                            gTimeSyncPayloadLength_c,
                            payload);
    shell_write("\r\nTime Sync sent with UWB Device Time:");
    shell_writeHexLe((uint8_t*)pUwbDevTime, (uint8_t)sizeof(uint64_t));
    shell_write("\r\n");
    shell_refresh();
    return result;
}
 /*! *********************************************************************************
 * \brief        Send URSK Derivation Dummy data, just simulates the URSK derivation process 
 *
 * \param[in]    deviceId         BLE peer device id
 * \param[in]    pData            Point of data
 * \param[in]    dataLen          Length of data 
 ********************************************************************************** */
bleResult_t CCC_CreatRangingKey(deviceId_t deviceId, uint8_t *pData, uint16_t dataLen)
{
    bleResult_t result = gBleSuccess_c;
    
    result = DK_SendMessage(deviceId,
                            maPeerInformation[deviceId].customInfo.psmChannelId,
                            gDKMessageTypeSEMessage_c,
                            gDkApduRS_c,
                            dataLen,
                            pData);
    
    return result;
}

/*! *********************************************************************************
 * \brief        Sends Ranging Service message of capability exchange response to vehicle.
 *               below parameter are common supported between device and vehicle.
 * 
 * \param[in]    deviceId         BLE peer device id
 * \param[in]    *ProtoVer        Point of Device-selected highest DK Protocol Version 
 * \param[in]    CfgId            UWB Config id.
 * \param[in]    PluseshapeCombo  Pulse shape combination.
 ********************************************************************************** */
bleResult_t CCC_SendRangingCapabilityRes(deviceId_t deviceId, uint8_t* ProtoVer, uint16_t CfgId, uint8_t PluseshapeCombo)
{
    bleResult_t result = gBleSuccess_c;
    uint8_t CapaBuf[gRangingCapabilityRspPayloadLength];
    
    FLib_MemCpy(&CapaBuf[0], ProtoVer, 2);
  
    CapaBuf[2] = (uint8_t)((CfgId & 0xFF00) >> 8);
    CapaBuf[3] = (uint8_t)(CfgId & 0x00FF);

    CapaBuf[4] = PluseshapeCombo;

    result = DK_SendMessage(deviceId,
                            maPeerInformation[deviceId].customInfo.psmChannelId,
                            gDKMessageTypeUWBRangingServiceMessage_c,
                            gRangingCapabilityRS_c,
                            gRangingCapabilityRspPayloadLength,
                            CapaBuf);        

    return result;
}


/*! *********************************************************************************
 * \brief        Sends Ranging Service message session response(RS-RS) to device.
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *session  Configuration point of Session struct
 ********************************************************************************** */
bleResult_t CCC_SendRangingSessionRsp(deviceId_t deviceId, SessionManagement_t *pSession )
{
    bleResult_t result = gBleSuccess_c;
    
    uint8_t aPayload[gRangingSessionRspPayloadLength] = {0}; 

    if (pSession == NULL)
    {
        result = gBleInvalidParameter_c;
    }
    else
    {
        aPayload[0] = pSession->RAN_Multiplier;
        aPayload[1] = UwbCapability.Slot_bitMask;
        FLib_MemCpy(&aPayload[2], UwbCapability.SYNC_Code_Index_Bitmaks, 4);
        aPayload[6] = pSession->SelectedChannel;
        aPayload[7] = UwbCapability.Hopping_Config_Bitmask;
        
        result = DK_SendMessage(deviceId,
                                maPeerInformation[deviceId].customInfo.psmChannelId,
                                gDKMessageTypeUWBRangingServiceMessage_c,
                                gRangingSessionRS_c,
                                gRangingSessionRspPayloadLength,
                                aPayload);
    }

    return result;
}

/*! *********************************************************************************
 * \brief        Sends Ranging Service message session response(RSS-RS) to device.
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *session  Configuration point of Session struct
 ********************************************************************************** */
bleResult_t CCC_SendRangingSessionSetupRsp(deviceId_t deviceId, SessionManagement_t *pSession )
{
    bleResult_t result = gBleSuccess_c;
    
    uint8_t aPayload[gRangingSessionSetupRspPayloadLength] = {0}; 

    if (pSession == NULL)
    {
        result = gBleInvalidParameter_c;
    }
    else
    {
        FLib_MemCpy(&aPayload[0], (uint8_t *)&pSession->STS_Index0, 4);
        FLib_MemCpy(&aPayload[4], (uint8_t *)&pSession->UWB_Time0, 8);
        FLib_MemCpy(&aPayload[12], (uint8_t *)&pSession->HOP_Mode_Key , 4);
        aPayload[16] = pSession->Selected_SYNC_Code_Index;
        
        result = DK_SendMessage(deviceId,
                                maPeerInformation[deviceId].customInfo.psmChannelId,
                                gDKMessageTypeUWBRangingServiceMessage_c,
                                gRangingSessionSetup_RS_c,
                                gRangingSessionSetupRspPayloadLength,
                                aPayload);
    }

    return result;
}


/*! *********************************************************************************
 * \brief        Process Ranging capability request(RC-RQ).
 *               It compare common supported parameters between device and vehicle,
 *               then select one. 
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *pPacket  Parameter point of RC-RQ payload
 ********************************************************************************** */
bleResult_t CCC_ProcessRangingCapabilityReq(deviceId_t deviceId, uint8_t* pPacket )
{
//    uint8_t *pData = &pPacket[gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c];
//    uint8_t i, paraLen;
//   
//    //Vehicle suppoerted Protocol_Version length
//    paraLen = pData[0];
//    pData ++;
//    while(paraLen)
//    {
//        paraLen -= 2;
//        if(FLib_MemCmp(&UwbCapability.Supported_Protocol_Version, pData, 2))
//        {
//            //Vehicle suppoerted Protocol_Version length
//            break;
//        }
//        pData += 2;
//    }   
//    pData += paraLen;
    
    /* In this CCC demo, we select Protocol_Version as 0x0100(1.0), UWB_Config_Id as 0 and 
       PulseShape as 0x11 */     
    UwbSessions.SelectedDkProtolVersion[0] = 0x01;
    UwbSessions.SelectedDkProtolVersion[1] = 0x00;
    UwbSessions.SelectedUwbConfigId = 0x0000;
    UwbSessions.SelectedPulseShapeCombo = 0x11;

    return gBleSuccess_c;
}

/*! *********************************************************************************
 * \brief        Process Ranging Service message session request(RS-RQ).
 *               Select Ranging session parameters 
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *pPacket  Parameter point of RS-RQ payload
 ********************************************************************************** */
bleResult_t CCC_ProcessRangingSessionReq(deviceId_t deviceId, uint8_t* pPacket )
{
    uint8_t paraLen, PeerUwbChannelBitmask;
    bool_t NeedTriggerExchangeUwbCapa = true; // should be a global variable to check if exchange UWB capability is need.
    uint8_t *pData = &pPacket[gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c];

    // Compare protocol version
    paraLen = UwbCapability.ProtoVer_Len;
    while(paraLen)
    {
        paraLen -= 2;
        if( FLib_MemCmp(&UwbCapability.Supported_Protocol_Version[paraLen], pData, 2))
        {
            // the protocol version can be supportted by local UWB
            NeedTriggerExchangeUwbCapa = false;
        }
    }
    // Compare uwb config id
    paraLen = UwbCapability.CfgId_Len;
    while(paraLen)
    {
        paraLen -= 2;
        if( FLib_MemCmp(&UwbCapability.Supported_Cfg_Id[paraLen], &pData[2], 2))
        {
            // the protocol version can be supportted by local UWB
            NeedTriggerExchangeUwbCapa = false;
        }
    }

    // Get session id
    UwbSessions.UwbSessionID = *((uint32_t *)&pData[4]);    
    
    // Compare PulseShape
    paraLen = UwbCapability.PluseshapeCombo_Len;
    while(paraLen)
    {
        paraLen -= 1;
        if( UwbCapability.Supported_Pluseshape_Combo[paraLen] == pData[8])
        {
            // the protocol version can be supportted by local UWB
            NeedTriggerExchangeUwbCapa = false;
        }
    }
    
    /* Select one of channel supported by both ranging device side, we set a fix channel 9 in this demo */
    PeerUwbChannelBitmask = UwbCapability.Channel_BitMask & pData[9];
    if((PeerUwbChannelBitmask & 0x02))
    {
        UwbSessions.SelectedChannel = 9;
    }
    
    // We just set this varaibe to 1 here, it may be set in other code branch. 
    UwbSessions.RAN_Multiplier = 1; 
    
    return gBleSuccess_c;    
}

/*! *********************************************************************************
 * \brief        Process Ranging Service message session setup request(RSS-RQ).
 *               Select Ranging session parameters 
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *pPacket  Parameter point of RSS-RQ payload
 ********************************************************************************** */
bleResult_t CCC_ProcessRangingSessionSetupReq(deviceId_t deviceId, uint8_t* pPacket )
{
    uint8_t *pData = &pPacket[gMessageHeaderSize_c + gPayloadHeaderSize_c + gLengthFieldSize_c];
    
    /* RAN multiplier*/
    UwbSessions.RAN_Multiplier = pData[0];
    
    UwbSessions.Number_Chaps_per_Slot = pData[1];
      
    UwbSessions.Number_Responders_Nodes = pData[2];
    
    UwbSessions.Number_Slots_per_Round = pData[3];
    
    UwbSessions.Selected_Hopping_Config_Bitmask = pData[8];
    
    // It's need to select SYNC_Code_Index, we select a fix SYNC Code Index.
    UwbSessions.Selected_SYNC_Code_Index = 10;
    
    UwbSessions.STS_Index0 = 0;
    UwbSessions.UWB_Time0 = 0;
    UwbSessions.HOP_Mode_Key = 0;
        
    return gBleSuccess_c;  
}

#endif
                            
/*! *********************************************************************************
* @}
********************************************************************************** */
