/*! *********************************************************************************
* \addtogroup Digital Key Device Application
* @{
********************************************************************************** */
/*! *********************************************************************************
* \file app_digital_key_device.h
*
* Copyright 2021 NXP
*
* NXP Confidential Proprietary
*
* No part of this document must be reproduced in any form - including copied,
* transcribed, printed or by any electronic means - without specific written
* permission from NXP.
********************************************************************************** */

#ifndef APP_DIGITAL_KEY_DEVICE_H
#define APP_DIGITAL_KEY_DEVICE_H

/************************************************************************************
*************************************************************************************
* Include
*************************************************************************************
************************************************************************************/
#include "gatt_types.h"
#include "digital_key_device.h"

#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
#include "Ranger4UciCmd.h"
#include "Ranger4_demo_task.h"
#endif
/************************************************************************************
*************************************************************************************
* Public macros
*************************************************************************************
************************************************************************************/
#define mcNumCharacteristics_c      (1U)
#define mcCharVehiclePsmIndex_c     (0U)

#define mcCharVehiclePsmLength_c    (2U)
#define mCharReadBufferLength_c     (13U)           /* length of the buffer */
/************************************************************************************
*************************************************************************************
* Public type definitions
*************************************************************************************
************************************************************************************/
typedef enum appState_tag{
    mAppIdle_c,
    mAppExchangeMtu_c,
    mAppServiceDisc_c,
    /* certificate exchange */
    mAppCCCPhase2WaitingForRequest_c,
    mAppCCCPhase2WaitingForVerify_c,
    mAppCCCWaitingForPairingReady_c,
    mAppPair,
    mAppRunning_c
}appState_t;

typedef struct appCustomInfo_tag
{
    uint16_t     hDkService;
    uint16_t     hPsmChannelChar;
    uint16_t     lePsmValue;
    uint16_t     psmChannelId;
    /* Add persistent information here */
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
#if RECEIVE_RANGING_RESULT_FROM_VEHICLE    
    uint16_t    hUwbService; 			// Service UUID handle
    uint16_t    hUwb;				// characteristic ID/handle for Notification 
    uint16_t    hUwbCccd;
    uint16_t    hUwbDesc;
#endif
#endif
}appCustomInfo_t;

typedef struct appPeerInfo_tag
{
    deviceId_t          deviceId;
    appCustomInfo_t     customInfo;
    bool_t              isBonded;
    appState_t          appState;
    gapLeScOobData_t    oobData;
    gapLeScOobData_t    peerOobData;
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
    uint32_t            RangingSessionID;
    uint64_t            TsUwbLocalDeviceTime;
    uint64_t            TsLocalDeviceEventCount;
    uint32_t            TsBleEvtDelay;           
    uint8_t             TsUwbDeviceTimeUncertainty;
    uint16_t            TsRetryDelay;
    bool_t              NeedsSendTimeSyncForPhyUpdate;
    bool_t              IsPsmChannelCreated;  
#endif
}appPeerInfo_t;

/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
************************************************************************************/
extern appPeerInfo_t maPeerInformation[gAppMaxConnections_c];
extern gattCharacteristic_t maCharacteristics[mcNumCharacteristics_c]; /* Index 0 - Vehicle PSM */
extern uint16_t mValVehiclePsm;
extern deviceId_t mCurrentPeerId;
/************************************************************************************
*************************************************************************************
* Public functions
*************************************************************************************
************************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
void APP_BleEventHandler(void *pData);
void BleApp_StateMachineHandler
(
    deviceId_t peerDeviceId,
    appEvent_t event
);

#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
 /*! *********************************************************************************
 * \brief        Send URSK Derivation Dummy data, just simulates the URSK derivation process 
 *
 * \param[in]    deviceId         BLE peer device id
 * \param[in]    pData            Point of data
 * \param[in]    dataLen          Length of data 
 ********************************************************************************** */
bleResult_t CCC_CreatRangingKey(deviceId_t deviceId, uint8_t *pData, uint16_t dataLen);

/*! *********************************************************************************
 * \brief        Sends Ranging Service message of capability exchange response to vehicle.
 *               below parameter are common supported between device and vehicle.
 * 
 * \param[in]    deviceId         BLE peer device id
 * \param[in]    *ProtoVer        Point of Device-selected highest DK Protocol Version 
 * \param[in]    CfgId            UWB Config id.
 * \param[in]    PluseshapeCombo  Pulse shape combination.
 ********************************************************************************** */
bleResult_t CCC_SendRangingCapabilityRes(deviceId_t deviceId, uint8_t* ProtoVer, uint16_t CfgId, uint8_t PluseshapeCombo);

/*! *********************************************************************************
 * \brief        Sends Ranging Service message session response(RS-RS) to device.
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *session  Configuration point of Session struct
 ********************************************************************************** */
bleResult_t CCC_SendRangingSessionRsp(deviceId_t deviceId, SessionManagement_t *pSession );

/*! *********************************************************************************
 * \brief        Sends Ranging Service message session response(RSS-RS) to device.
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *session  Configuration point of Session struct
 ********************************************************************************** */
bleResult_t CCC_SendRangingSessionSetupRsp(deviceId_t deviceId, SessionManagement_t *pSession );

/*! *********************************************************************************
 * \brief        Process Ranging capability request(RC-RQ).
 *               It compare common supported parameters between device and vehicle,
 *               then select one. 
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *pPacket  Parameter point of RC-RQ payload
 ********************************************************************************** */
bleResult_t CCC_ProcessRangingCapabilityReq(deviceId_t deviceId, uint8_t* pPacket );


/*! *********************************************************************************
 * \brief        Process Ranging Service message session request(RS-RQ).
 *               Select Ranging session parameters 
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *pPacket  Parameter point of RS-RQ payload
 ********************************************************************************** */
bleResult_t CCC_ProcessRangingSessionReq(deviceId_t deviceId, uint8_t* pPacket );
/*! *********************************************************************************
 * \brief        Process Ranging Service message session setup request(RSS-RQ).
 *               Select Ranging session parameters 
 *
 * \param[in]    deviceId  BLE peer device id
 * \param[in]    *pPacket  Parameter point of RSS-RQ payload
 ********************************************************************************** */
bleResult_t CCC_ProcessRangingSessionSetupReq(deviceId_t deviceId, uint8_t* pPacket );

/* CCC Time Sync */
bleResult_t CCC_SendTimeSync(deviceId_t deviceId,
                             uint64_t *pDevEvtCnt,
                             uint64_t *pUwbDevTime,
                             uint8_t success);
#else
#define CCC_SendRangingCapabilityRes
#define CCC_SendRangingSessionRsp
#define CCC_CreatRangingKey
#define CCC_SendRangingSessionSetupRsp
#define CCC_ProcessRangingCapabilityReq
#define CCC_ProcessRangingSessionReq
#define CCC_ProcessRangingSessionSetupReq
#endif

#ifdef __cplusplus
}
#endif

#endif /* APP_DIGITAL_KEY_DEVICE_H */
