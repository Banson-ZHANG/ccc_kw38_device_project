/*! *********************************************************************************
* \addtogroup Digital Key Device Application
* @{
********************************************************************************** */
/*! *********************************************************************************
* \file shell_digital_key_device.c
*
* Copyright 2021 NXP
*
* NXP Confidential Proprietary
*
* No part of this document must be reproduced in any form - including copied,
* transcribed, printed or by any electronic means - without specific written
* permission from NXP.
********************************************************************************** */

/************************************************************************************
*************************************************************************************
* Include
*************************************************************************************
************************************************************************************/
/* Framework / Drivers */
#include "EmbeddedTypes.h"
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
#include "shell.h"
#endif
#include "Reset.h"

/* BLE Host Stack */
#include "gap_interface.h"

#include "digital_key_device.h"
#include "shell_digital_key_device.h"

#include "ApplMain.h"

/************************************************************************************
*************************************************************************************
* Private macros
*************************************************************************************
************************************************************************************/

/************************************************************************************
*************************************************************************************
* Private type definitions
*************************************************************************************
************************************************************************************/

/************************************************************************************
*************************************************************************************
* Private functions prototypes
*************************************************************************************
************************************************************************************/
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
/* Shell */
static int8_t ShellReset_Command(uint8_t argc, char * argv[]);
static int8_t ShellFactoryReset_Command(uint8_t argc, char * argv[]);
static int8_t ShellStartDiscovery_Command(uint8_t argc, char * argv[]);
static int8_t ShellStopDiscovery_Command(uint8_t argc, char * argv[]);
static int8_t ShellDisconnect_Command(uint8_t argc, char * argv[]);
static int8_t ShellSetBondingData_Command(uint8_t argc, char * argv[]);
static int8_t ShellListBondedDev_Command(uint8_t argc, char * argv[]);
static int8_t ShellRemoveBondedDev_Command(uint8_t argc, char * argv[]);

static void ShellRemoveBD_PrintUsage(void);
static void ShellSetBD_PrintUsage(void);
static uint8_t BleApp_ParseHexValue(char* pInput);
static uint32_t BleApp_AsciiToHex(char *pString, uint32_t strLen);
/************************************************************************************
*************************************************************************************
* Private memory declarations
*************************************************************************************
************************************************************************************/

static cmd_tbl_t mResetCmd =
{
    .name = "reset",
    .maxargs = 1,
    .repeatable = 1,
    .cmd = ShellReset_Command,
    .usage = "Reset MCU.",
    .help = NULL
};

static cmd_tbl_t mFactoryResetCmd =
{
    .name = "factoryreset",
    .maxargs = 1,
    .repeatable = 1,
    .cmd = ShellFactoryReset_Command,
    .usage = "Factory Reset.",
    .help = NULL
};

static cmd_tbl_t mSdCmd =
{
    .name = "sd",
    .maxargs = 1,
    .repeatable = 1,
    .cmd = ShellStartDiscovery_Command,
    .usage = "Start Discovery for Owner Pairing or Passive Entry.",
    .help = NULL
};

static cmd_tbl_t mSpdCmd =
{
    .name = "spd",
    .maxargs = 1,
    .repeatable = 1,
    .cmd = ShellStopDiscovery_Command,
    .usage = "Stop Discovery.",
    .help = NULL
};

static cmd_tbl_t mDcntCmd =
{
    .name = "dcnt",
    .maxargs = 1,
    .repeatable = 1,
    .cmd = ShellDisconnect_Command,
    .usage = "Disconnect all peers.",
    .help = NULL
};

static cmd_tbl_t mSetBondingDataCmd =
{
    .name = "setbd",
    .maxargs = 6,
    .repeatable = 1,
    .cmd = ShellSetBondingData_Command,
    .usage = "Set bonding data.",
    .help = NULL
};

static cmd_tbl_t mListBondedDevCmd =
{
    .name = "listbd",
    .maxargs = 1,
    .repeatable = 1,
    .cmd = ShellListBondedDev_Command,
    .usage = "List bonded devices.",
    .help = NULL
};

static cmd_tbl_t mRemoveBondedDevCmd =
{
    .name = "removebd",
    .maxargs = 2,
    .repeatable = 1,
    .cmd = ShellRemoveBondedDev_Command,
    .usage = "Remove bonded devices.",
    .help = NULL
};
#endif
/************************************************************************************
*************************************************************************************
* Private functions prototypes
*************************************************************************************
************************************************************************************/


/************************************************************************************
*************************************************************************************
* Public functions
*************************************************************************************
************************************************************************************/

/*! *********************************************************************************
* \brief  Initializes the SHELL module .
*
* \param[in]  prompt the string which will be used for command prompt
*
* \remarks
*
********************************************************************************** */
void AppShellInit(const char* prompt)
{
    shell_init(prompt);
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)   
    (void)shell_register_function(&mResetCmd);
    (void)shell_register_function(&mFactoryResetCmd);
    (void)shell_register_function(&mSdCmd);
    (void)shell_register_function(&mSpdCmd);
    (void)shell_register_function(&mDcntCmd);
    (void)shell_register_function(&mSetBondingDataCmd);
    (void)shell_register_function(&mListBondedDevCmd);
    (void)shell_register_function(&mRemoveBondedDevCmd);
#endif
}

/************************************************************************************
*************************************************************************************
* Private functions
*************************************************************************************
************************************************************************************/
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
/*! *********************************************************************************
* \brief        Save Bonding Data on device.
*
* \param[in]    argc           Number of arguments
* \param[in]    argv           Pointer to arguments
*
* \return       shell_status_t  Returns the command processing status
********************************************************************************** */
static int8_t ShellSetBondingData_Command(uint8_t argc, char * argv[])
{
    if (argc == 6U)
    {
        if(mpfBleEventHandler != NULL)
        {
            appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(appBondingData_t));
            if(pEventData != NULL)
            {
                pEventData->appEvent = mAppEvt_Shell_SetBondingData_Command_c;
                pEventData->eventData.pData = pEventData + 1;
                appBondingData_t *pAppBondingEventData = pEventData->eventData.pData;
                if ( sizeof(uint8_t) == BleApp_ParseHexValue(argv[1]) )
                {
                    pAppBondingEventData->nvmIndex = (uint8_t)*argv[1];
                }
                
                if ( sizeof(bleAddressType_t) == BleApp_ParseHexValue(argv[2]) )
                {
                    pAppBondingEventData->addrType = (uint8_t)*argv[2];
                }
                
                if ( gcBleDeviceAddressSize_c ==  BleApp_ParseHexValue(argv[3]) )
                {
                    FLib_MemCpy(pAppBondingEventData->deviceAddr, argv[3], gcBleDeviceAddressSize_c);
                }
                
                if ( gcSmpMaxLtkSize_c == BleApp_ParseHexValue(argv[4]) )
                {
                    FLib_MemCpy(pAppBondingEventData->aLtk, argv[4], gcSmpMaxLtkSize_c);
                }
                
                if ( gcSmpIrkSize_c ==  BleApp_ParseHexValue(argv[5]) )
                {
                    FLib_MemCpy(pAppBondingEventData->aIrk, argv[5], gcSmpIrkSize_c);
                }
                (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
            }
        }
    }
    else
    {
        ShellSetBD_PrintUsage();
    }
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
* \brief        List bonded devices.
*
* \param[in]    argc           Number of arguments
* \param[in]    argv           Pointer to arguments
*
* \return       shell_status_t  Returns the command processing status
********************************************************************************** */
static int8_t ShellListBondedDev_Command(uint8_t argc, char * argv[])
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
        if(pEventData != NULL)
        {
            pEventData->appEvent = mAppEvt_Shell_ListBondedDev_Command_c;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
* \brief        remove bonded devices.
*
* \param[in]    argc           Number of arguments
* \param[in]    argv           Pointer to arguments
*
* \return       shell_status_t  Returns the command processing status
********************************************************************************** */
static int8_t ShellRemoveBondedDev_Command(uint8_t argc, char * argv[])
{
    if (argc == 2U)
    {
        if(mpfBleEventHandler != NULL)
        {
            appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
            if(pEventData != NULL)
            {
                pEventData->appEvent = mAppEvt_Shell_RemoveBondedDev_Command_c;
                if ( sizeof(uint8_t) == BleApp_ParseHexValue(argv[1]) )
                {
                    /* Store nvm index to be removed in eventData.peerDeviceId  */
                    pEventData->eventData.peerDeviceId = (uint8_t)*argv[1];
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
    }
    else
    {
        ShellRemoveBD_PrintUsage();
    }
    
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
 * \brief        Reset MCU.
 *
 ********************************************************************************** */
static int8_t ShellReset_Command(uint8_t argc, char * argv[])
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
        if(pEventData != NULL)
        {
            pEventData->appEvent = mAppEvt_Shell_Reset_Command_c;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
 * \brief        Factory Reset.
 *
 ********************************************************************************** */
static int8_t ShellFactoryReset_Command(uint8_t argc, char * argv[])
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
        if(pEventData != NULL)
        {
            pEventData->appEvent = mAppEvt_Shell_FactoryReset_Command_c;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
 * \brief        Initialize Owner Pairing or Passive Entry.
 *
 ********************************************************************************** */
static int8_t ShellStartDiscovery_Command(uint8_t argc, char * argv[])
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
        if(pEventData != NULL)
        {
            pEventData->appEvent = mAppEvt_Shell_ShellStartDiscovery_Command_c;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
 * \brief        Stop discovery, if active.
 *
 ********************************************************************************** */
static int8_t ShellStopDiscovery_Command(uint8_t argc, char * argv[])
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
        if(pEventData != NULL)
        {
            pEventData->appEvent = mAppEvt_Shell_StopDiscovery_Command_c;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
 * \brief        Disconnect device.
 *
 ********************************************************************************** */
static int8_t ShellDisconnect_Command(uint8_t argc, char * argv[])
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
        if(pEventData != NULL)
        {
            pEventData->appEvent = mAppEvt_Shell_Disconnect_Command_c;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
    
    return CMD_RET_SUCCESS;
}

/*! *********************************************************************************
 * \brief        Print usage for removebd command.
 *
 ********************************************************************************** */
static void ShellRemoveBD_PrintUsage(void)
{
    shell_write("\r\nUsage: \
                 \r\nremovebd nvm_index \
                 \r\n");
}

/*! *********************************************************************************
 * \brief        Print usage for setbd command.
 *
 ********************************************************************************** */
static void ShellSetBD_PrintUsage(void)
{
    shell_write("\r\nUsage: \
                 \r\nsetbd nvm_index addr_type peer_device_address ltk irk  \
                 \r\n");
}
                
static uint8_t BleApp_ParseHexValue(char* pInput)
{
    uint8_t i, length = (uint8_t)strlen(pInput);
    uint32_t value;
    uint8_t result = 0U;

    /* If the hex misses a 0, return error. Process single character */
    if ((length == 1U) || (length % 2U) == 0U)
    {
        if(0 == strncmp(pInput, "0x", 2))
        {
            length -= 2U;

            /* Save as little endian hex value */
            value = BleApp_AsciiToHex(pInput + 2, FLib_StrLen(pInput+2));

            FLib_MemCpy(pInput, &value, sizeof(uint32_t));

            result = length/2U;
        }
        else if (length > 1U)
        {
            char octet[2];

            /* Save as big endian hex */
            for(i=0U;i < length / 2U; i++)
            {
                FLib_MemCpy(octet, &pInput[i*2U], 2U);

                pInput[i] = (char)BleApp_AsciiToHex(octet, 2U);
            }
            result = length/2U;
        }
        else
        {
            /* Convert single character from ASCII to hex */
            pInput[0] = (char)BleApp_AsciiToHex(pInput, length);
            result = length;
        }
    }

    return result;
}

/*!*************************************************************************************************
 *  \brief  Converts a string into hex.
 *
 *  \param  [in]    pString     pointer to string
 *  \param  [in]    strLen      string length
 *
 * \return uint32_t value in hex
 **************************************************************************************************/
static uint32_t BleApp_AsciiToHex(char *pString, uint32_t strLen)
{
    uint32_t length = strLen;
    uint32_t retValue = 0U;
    int32_t hexDig = 0;
    bool_t validChar;

    /* Loop until reaching the end of the string or the given length */
    while ((length != 0U) && (pString != NULL))
    {
        hexDig = 0;
        validChar = FALSE;

        /* digit 0-9 */
        if (*pString >= '0' && *pString <= '9')
        {
            hexDig = *pString - '0';
            validChar = TRUE;
        }

        /* character 'a' - 'f' */
        if (*pString >= 'a' && *pString <= 'f')
        {
            hexDig = *pString - 'a' + 10;
            validChar = TRUE;
        }

        /* character 'A' - 'B' */
        if (*pString >= 'A' && *pString <= 'F')
        {
            hexDig = *pString - 'A' + 10;
            validChar = TRUE;
        }

        /* a hex digit is 4 bits */
        if (validChar == TRUE)
        {
            retValue = (uint32_t)((retValue << 4U) ^ (uint32_t)hexDig);
        }

        /* Increment position */
        pString++;
        length--;
    }

    return retValue;
}
#endif