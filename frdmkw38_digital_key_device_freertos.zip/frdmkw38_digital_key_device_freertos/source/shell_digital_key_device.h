/*! *********************************************************************************
 * \defgroup Digital Key Device Application
 * @{
 ********************************************************************************** */
/*! *********************************************************************************
* \file shell_digital_key_device.h
*
* Copyright 2021 NXP
*
* NXP Confidential Proprietary
*
* No part of this document must be reproduced in any form - including copied,
* transcribed, printed or by any electronic means - without specific written
* permission from NXP.
********************************************************************************** */

#ifndef SHELL_DIGITAL_KEY_H
#define SHELL_DIGITAL_KEY_H
#include "app_preinclude.h"
/*************************************************************************************
**************************************************************************************
* Public macros
**************************************************************************************
*************************************************************************************/
#if !defined(gAppUseShellInApplication_d) || (defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 0))
    #define shell_write(function, ...)
    #define shell_writeHex(function, ...)
    #define shell_cmd_finished(function, ...)
    #define shell_init(function, ...)
    #define shell_register_function(function, ...)
    #define shell_refresh(function, ...)
    #define shell_writeHexLe(function, ...)
    #define CMD_RET_SUCCESS   0
#endif
/************************************************************************************
*************************************************************************************
* Public type definitions
*************************************************************************************
************************************************************************************/
typedef struct appBondingData_tag
{
    uint8_t nvmIndex;
    uint8_t addrType;
    uint8_t deviceAddr[6];
    uint8_t aLtk[16];
    uint8_t aIrk[16];
}appBondingData_t;
/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
********************************************************************************** */

/************************************************************************************
*************************************************************************************
* Public prototypes
*************************************************************************************
************************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

void AppShellInit(const char* prompt);

#ifdef __cplusplus
}
#endif


#endif /* SHELL_DIGITAL_KEY_H */

/*! *********************************************************************************
 * @}
 ********************************************************************************** */
