/*! *********************************************************************************
* \addtogroup Digital Key Device
* @{
********************************************************************************** */
/*! *********************************************************************************
* \file digital_key_device.c
*
* Copyright 2020-2021 NXP
*
* NXP Confidential Proprietary
*
* No part of this document must be reproduced in any form - including copied,
* transcribed, printed or by any electronic means - without specific written
* permission from NXP.
********************************************************************************** */

/************************************************************************************
*************************************************************************************
* Include
*************************************************************************************
************************************************************************************/
/* Framework / Drivers */

#include "app_preinclude.h"
#include "EmbeddedTypes.h"
#include "Keyboard.h"
#include "LED.h"
#include "Panic.h"
#include "TimersManager.h"
#include "FunctionLib.h"
#include "MemManager.h"
#include "Reset.h"
#if defined(gAppUseShellInApplication_d) && (gAppUseShellInApplication_d == 1)
#include "shell.h"
#endif
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
#include "PWR_Interface.h"
#include "PWR_Configuration.h"
#endif
#include "NVM_Interface.h"

/* BLE Host Stack */
#include "gatt_server_interface.h"
#include "gatt_client_interface.h"
#include "gap_interface.h"
#include "gatt_db_app_interface.h"
#include "gatt_db_handles.h"


/* Profile / Services */
#include "digital_key_interface.h"

#include "ble_conn_manager.h"
#include "ble_service_discovery.h"

#include "ApplMain.h"
#include "digital_key_device.h"

#include "app_digital_key_device.h"
#include "shell_digital_key_device.h"

    
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
#include "Ranger4UciCmd.h"
#include "Ranger4_demo_task.h"
#include "Messaging.h"
#endif

#include "SerialManager.h"
#include "board.h"
/************************************************************************************
*************************************************************************************
* Private macros
*************************************************************************************
************************************************************************************/
#define UWB_INITIATION_TIME_DEMO        100u   // milliseconds       

/************************************************************************************
*************************************************************************************
* Private type definitions
*************************************************************************************
************************************************************************************/
/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
************************************************************************************/
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U)) 
// Capability of UWB should achieve from NCJ29D5 via UCI command.
UwbCapabilityManagement_t UwbCapability;
// UWB Ranging Session
SessionManagement_t UwbSessions;

uint64_t TsUwbCurrentTimeStamp = 0;
#endif
/************************************************************************************
*************************************************************************************
* Private memory declarations
*************************************************************************************
************************************************************************************/
static bool_t   mScanningOn = FALSE;
static bool_t   mFoundDeviceToConnect = FALSE;

/* Timers */
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
static tmrTimerID_t mAppTimerId;
#endif

/* application callback */
pfBleCallback_t mpfBleEventHandler = NULL;

/* This global will be TRUE if the user adds or removes a bond */
bool_t gPrivacyStateChangedByUser = FALSE;


#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))  

static appUwbTsPeerDevice_t TsPeerDeviceList;

/* Buffer used for Characteristic related procedures */
static gattAttribute_t *mpCharProcBuffer = NULL;

/*** Ranger4 core configuration ***/
static uint8_t UwbLowPowerMode[1] = {0x00};
static Ranger4Uci_ParameterStructure_t UwbCoreCfg[1] =
{
    {
        .ID = R4_PARAM_LOW_POWER_MODE,
        .length = 0x01,
        .paramValue = UwbLowPowerMode
    }
};

static uint8_t UwbCoreCfgSize = NumberOfElements(UwbCoreCfg); 

static Ranger4Uci_DeviceStatusType_t mUwbDeviceStatus = R4_UCI_DEVICE_STATUS_UNDEFINE;

static uint16_t mRanger4Distance = 0;
static bool  mIsRanger4Init = false;
#endif


#if (gAppUseShellInApplication_d == 0)    
uint8_t  gAppSerMgrIf;
#else
uint8_t  gAppSerMgrIf;
#endif
/************************************************************************************
*************************************************************************************
* Private functions prototypes
*************************************************************************************
************************************************************************************/

/* Host Stack callbacks */
static void BleApp_ScanningCallback
(
    gapScanningEvent_t* pScanningEvent
);

static void BleApp_ConnectionCallback
(
    deviceId_t peerDeviceId,
    gapConnectionEvent_t* pConnectionEvent
);

static void BleApp_ConnectionCallback_SignalSimpleEvents(deviceId_t peerDeviceId, appEvent_t connectionCallbackEvent);

static void BleApp_GattClientCallback
(
    deviceId_t              serverDeviceId,
    gattProcedureType_t     procedureType,
    gattProcedureResult_t   procedureResult,
    bleResult_t             error
);

static void BleApp_ServiceDiscoveryCallback
(
    deviceId_t peerDeviceId,
    servDiscEvent_t* pEvent
);

/* PSM callbacks */
static void BleApp_L2capPsmDataCallback (deviceId_t deviceId, uint16_t lePsm, uint8_t* pPacket, uint16_t packetLength);
static void BleApp_L2capPsmControlCallback (l2capControlMessage_t* pMessage);

static void BleApp_Config(void);

static bool_t CheckScanEventLegacy(gapScannedDevice_t* pData);
static bool_t CheckScanEventExtended(gapExtScannedDevice_t* pData);

static void BleApp_StoreServiceHandles
(
    deviceId_t      peerDeviceId,
    gattService_t   *pService
);
static void BleApp_GenericCallback_HandlePrivacyEvents(gapGenericEvent_t* pGenericEvent);
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
static void ScanningTimeoutTimerCallback(void* pParam);
#endif
  
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U)) 

#if RECEIVE_RANGING_RESULT_FROM_VEHICLE    

/*! *********************************************************************************
 * \brief        Handles GATT client notification callback from host stack.
 *
 * \param[in]    serverDeviceId              GATT Server device ID.
 * \param[in]    characteristicValueHandle   Handle.
 * \param[in]    aValue                      Pointer to value.
 * \param[in]    valueLength                 Value length.
 ********************************************************************************** */
static void BleApp_GattNotificationCallback
(
    deviceId_t serverDeviceId,
    uint16_t characteristicValueHandle, 
    uint8_t *aValue,
    uint16_t valueLength
);
#endif

/*! *********************************************************************************
 * \brief        UCI response callback function, this function could be rework by 
 *               customer application code
 *
 * \param[in]    frame   UCI response frame
 ***********************************************************************************/
static void Ranger4App_RspCallback(phscaR4CadsTypesIntf_UciFrame_t * frame);

/*! *********************************************************************************
 * \brief        UCI notification callback function, this function could be rework by 
 *               customer application code
 *
 * \param[in]    frame   UCI response frame
 ***********************************************************************************/
static void Ranger4App_NtfCallback(phscaR4CadsTypesIntf_UciFrame_t * frame);


/*! *********************************************************************************
 * \brief        Process Time Stamp get from UWB
 *
 * \param[in]    pPayload   point of UWB UCI response frame        
 ********************************************************************************** */
static void ProcessUwbTimeStamp(uint8_t * pPayload, phscaR4CadsTypesIntf_UciStatusCode_t StateCode);
#endif

/************************************************************************************
*************************************************************************************
* Public memory declarations
*************************************************************************************
************************************************************************************/
/************************************************************************************
*************************************************************************************
* Public functions
*************************************************************************************
************************************************************************************/

/*! *********************************************************************************
* \brief    Initializes application specific functionality before the BLE stack init.
*
********************************************************************************** */
void BleApp_Init(void)
{
    uint8_t mPeerId = 0;
   /* UI */
    AppShellInit("Device>");
#if (gAppUseShellInApplication_d == 0)    
    Serial_InitManager();

    /* Register Serial Manager interface */
    Serial_InitInterface(&gAppSerMgrIf, APP_SERIAL_INTERFACE_TYPE, APP_SERIAL_INTERFACE_INSTANCE);
    /* Set serial baud rate */
    (void)Serial_SetBaudRate(gAppSerMgrIf, APP_SERIAL_INTERFACE_SPEED);    
#endif

    for (mPeerId = 0; mPeerId < (uint8_t)gAppMaxConnections_c; mPeerId++)
    {
        maPeerInformation[mPeerId].deviceId = gInvalidDeviceId_c;
        FLib_MemSet(&maPeerInformation[mPeerId].oobData, 0x00, sizeof(gapLeScOobData_t));
        FLib_MemSet(&maPeerInformation[mPeerId].peerOobData, 0x00, sizeof(gapLeScOobData_t));
    }
    
    BleApp_RegisterEventHandler(APP_BleEventHandler);
}

/*! *********************************************************************************
 * \brief        Register function to handle events from BLE to APP
 *
 * \param[in]    pCallback       event handler
 ********************************************************************************** */
void BleApp_RegisterEventHandler(pfBleCallback_t pfBleEventHandler)
{
    mpfBleEventHandler = pfBleEventHandler;
}

/*! *********************************************************************************
* \brief    Starts the BLE application.
*
********************************************************************************** */
void BleApp_Start(void)
{
    if (!mScanningOn)
    {
        /* Set low power mode */
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
        (void)PWR_ChangeDeepSleepMode(gAppDeepSleepMode_c);
#endif
        /* Start scanning */
        (void)App_StartScanning(&gScanParams, BleApp_ScanningCallback, gGapDuplicateFilteringEnable_c, gGapScanContinuously_d, gGapScanPeriodicDisabled_d);
    }
}

/*! *********************************************************************************
* \brief        Handles keyboard events.
*
* \param[in]    events    Key event structure.
********************************************************************************** */
void BleApp_HandleKeys(key_event_t events)
{
    switch (events)
    {
        /* Start on button press if low-power is disabled */
        case gKBD_EventPressPB1_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_KBD_EventPressPB1_c;
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;

        /* Disconnect on long button press */
        case gKBD_EventLongPB1_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_KBD_EventLongPB1_c;
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;
        
        case gKBD_EventVeryLongPB1_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_KBD_EventVeryLongPB1_c;
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;

        case gKBD_EventPressPB2_c:  /* Fall-through */
        case gKBD_EventLongPB2_c:   /* Fall-through */
        default:
        {
            ; /* No action required */
            break;
        }
    }
}

/*! *********************************************************************************
* \brief        Handles BLE generic callback.
*
* \param[in]    pGenericEvent    Pointer to gapGenericEvent_t.
********************************************************************************** */
void BleApp_GenericCallback (gapGenericEvent_t* pGenericEvent)
{
    /* Call BLE Conn Manager */
    BleConnManager_GenericEvent(pGenericEvent);

    switch (pGenericEvent->eventType)
    {
        case gInitializationComplete_c:
        {
            BleApp_Config();
        }
        break;
        
        case gLePhyEvent_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(gapPhyEvent_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_GenericCallback_LePhyEvent_c;
                    pEventData->eventData.pData = pEventData + 1;
                    FLib_MemCpy(pEventData->eventData.pData, &pGenericEvent->eventData.phyEvent, sizeof(gapPhyEvent_t));  
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;
        
        case gLeScLocalOobData_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(gapLeScOobData_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_GenericCallback_LeScLocalOobData_c;
                    pEventData->eventData.pData = pEventData + 1;
                    FLib_MemCpy(pEventData->eventData.pData, &pGenericEvent->eventData.localOobData, sizeof(gapLeScOobData_t));  
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;
        
        case gRandomAddressReady_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(gcBleDeviceAddressSize_c));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_GenericCallback_RandomAddressReady_c;
                    pEventData->eventData.pData = pEventData +1;
                    FLib_MemCpy(pEventData->eventData.pData, pGenericEvent->eventData.addrReady.aAddress, sizeof(gcBleDeviceAddressSize_c));  
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;
        
        case gControllerNotificationEvent_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(bleNotificationEvent_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_GenericCallback_CtrlNotifEvent_c;
                    pEventData->eventData.pData = pEventData +1U;
                    FLib_MemCpy(pEventData->eventData.pData, &pGenericEvent->eventData.notifEvent, sizeof(bleNotificationEvent_t));  
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;
        
        case gBondCreatedEvent_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(bleBondCreatedEvent_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_GenericCallback_BondCreatedEvent_c;
                    pEventData->eventData.pData = pEventData + 1;
                    FLib_MemCpy(pEventData->eventData.pData, &pGenericEvent->eventData.bondCreatedEvent, sizeof(bleBondCreatedEvent_t));  
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;
        
        case gHostPrivacyStateChanged_c:
        case gControllerPrivacyStateChanged_c:
        {
            BleApp_GenericCallback_HandlePrivacyEvents(pGenericEvent);
        }
        break;
        
        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/************************************************************************************
*************************************************************************************
* Private functions
*************************************************************************************
************************************************************************************/

/*! *********************************************************************************
* \brief        Handler of gHostPrivacyStateChanged_c and 
*               gControllerPrivacyStateChanged_c from BleApp_GenericCallback.
*
* \param[in]    pGenericEvent    Pointer to gapGenericEvent_t.
********************************************************************************** */
static void BleApp_GenericCallback_HandlePrivacyEvents(gapGenericEvent_t* pGenericEvent)
{
    switch (pGenericEvent->eventType)
    {   
        case gHostPrivacyStateChanged_c:
        {
            if (!pGenericEvent->eventData.newHostPrivacyState)
            {
                if(gPrivacyStateChangedByUser)
                {
                    gPrivacyStateChangedByUser = FALSE;
                    /* Host privacy disabled because a bond was removed
                       or added. Enable privacy. */
                    (void)BleConnManager_EnablePrivacy();
                }
            }
        }
        break;
        
        case gControllerPrivacyStateChanged_c:
        {
            if (!pGenericEvent->eventData.newControllerPrivacyState)
            {
                if(gPrivacyStateChangedByUser)
                {
                    gPrivacyStateChangedByUser = FALSE;
                    /* Controller privacy disabled because a bond was removed
                       or added. Enable privacy. */
                    (void)BleConnManager_EnablePrivacy();
                }
            }
        }
        break;
        
        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*! *********************************************************************************
* \brief        Configures BLE Stack after initialization. Usually used for
*               configuring advertising, scanning, white list, services, et al.
*
********************************************************************************** */
static void BleApp_Config(void)
{
    uint8_t mPeerId = 0;

    /* Configure as GAP Central */
    BleConnManager_GapCommonConfig();

    /* Register for callbacks*/
    (void)App_RegisterGattClientProcedureCallback(BleApp_GattClientCallback);
#if RECEIVE_RANGING_RESULT_FROM_VEHICLE    
    (void) App_RegisterGattClientNotificationCallback(BleApp_GattNotificationCallback);
#endif
    BleServDisc_RegisterCallback(BleApp_ServiceDiscoveryCallback);

    /* Initialize private variables */
    for (mPeerId = 0; mPeerId < (uint8_t)gAppMaxConnections_c; mPeerId++)
    {
        maPeerInformation[mPeerId].appState = mAppIdle_c;
        maPeerInformation[mPeerId].deviceId = gInvalidDeviceId_c;
    }
    mScanningOn = FALSE;
    mFoundDeviceToConnect = FALSE;

    /* Init timestamps */
    TMR_TimeStampInit();

    /* Allocate scan timeout timer */
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
    mAppTimerId = TMR_AllocateTimer();
#endif

    /* Register stack callbacks */
    (void)App_RegisterLeCbCallbacks(BleApp_L2capPsmDataCallback, BleApp_L2capPsmControlCallback);

    shell_write("\r\nDigital Key Device.\r\n");
    shell_cmd_finished();

#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
    /* Allow entering sleep mode until any user interaction */
    (void)PWR_ChangeDeepSleepMode(cPWR_DeepSleepMode);
    PWR_AllowDeviceToSleep();
#endif
    (void)Gap_ControllerEnhancedNotification(((uint32_t)gNotifConnCreated_c | (uint32_t)gNotifPhyUpdateInd_c), 0U);
       
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U)) 
    
    TsPeerDeviceList.head = 0;
    TsPeerDeviceList.tail = 0;
    TsPeerDeviceList.maxListSize = 32; // this variable must same as size of TsPeerDeviceList.DeviceIdList
    FLib_MemSet(TsPeerDeviceList.DeviceIdList, 0xFF, TsPeerDeviceList.maxListSize);
    
    Ranger4App_RegisterCallback(Ranger4App_RspCallback, Ranger4App_NtfCallback);
    Ranger4App_task_Init();
#endif
}

/*! *********************************************************************************
* \brief        Handles Shell_Factory Reset Command event.
********************************************************************************** */
void BleApp_FactoryReset(void)
{
    /* Erase NVM Datasets */
    NVM_Status_t status = NvFormat();
    if (status != gNVM_OK_c)
    {
         /* NvFormat exited with an error status */ 
         panic(0, (uint32_t)BleApp_FactoryReset, 0, 0);
    }
    
    /* Reset MCU */
    ResetMCU();
}

/*! *********************************************************************************
* \brief        Handles BLE Scanning callback from host stack.
*
* \param[in]    pScanningEvent    Pointer to gapScanningEvent_t.
********************************************************************************** */
static void BleApp_ScanningCallback (gapScanningEvent_t* pScanningEvent)
{ 
    switch (pScanningEvent->eventType)
    {
        case gDeviceScanned_c:
        {
            /* Check if the scanned device implements the DK Service */
            if( FALSE == mFoundDeviceToConnect )
            {
                /* Advertising for Passive Entry has an empty payload - if we have a bond with the device, connect */
                /* Only check the payload if we do not have a bond */
                if (pScanningEvent->eventData.scannedDevice.advertisingAddressResolved == FALSE)
                {
                    mFoundDeviceToConnect = CheckScanEventLegacy(&pScanningEvent->eventData.scannedDevice);
                }

                if (mFoundDeviceToConnect || (pScanningEvent->eventData.scannedDevice.advertisingAddressResolved == TRUE))
                {
                    mFoundDeviceToConnect = TRUE;
                    /* Set connection parameters and stop scanning. Connect on gScanStateChanged_c. */
                    gConnReqParams.peerAddressType = pScanningEvent->eventData.scannedDevice.addressType;
                    FLib_MemCpy(gConnReqParams.peerAddress,
                                pScanningEvent->eventData.scannedDevice.aAddress,
                                sizeof(bleDeviceAddress_t));

                    (void)Gap_StopScanning();
#if defined(gAppUsePrivacy_d) && (gAppUsePrivacy_d)
                    gConnReqParams.usePeerIdentityAddress = pScanningEvent->eventData.scannedDevice.advertisingAddressResolved;
#endif
                }
            }
        }
        break;

        case gExtDeviceScanned_c:
        {
            /* Check if the scanned device implements the DK Service */
            if( FALSE == mFoundDeviceToConnect )
            {
                /* Advertising for Passive Entry has an empty payload - if we have a bond with the device, connect */
                /* Only check the payload if we do not have a bond */
                if (pScanningEvent->eventData.extScannedDevice.advertisingAddressResolved == FALSE)
                {
                    mFoundDeviceToConnect = CheckScanEventExtended(&pScanningEvent->eventData.extScannedDevice);
                }

                if (mFoundDeviceToConnect || (pScanningEvent->eventData.extScannedDevice.advertisingAddressResolved == TRUE))
                {
                    mFoundDeviceToConnect = TRUE;
                    /* Set connection parameters and stop scanning. Connect on gScanStateChanged_c. */
                    gConnReqParams.peerAddressType = pScanningEvent->eventData.extScannedDevice.addressType;
                    FLib_MemCpy(gConnReqParams.peerAddress,
                                pScanningEvent->eventData.extScannedDevice.aAddress,
                                sizeof(bleDeviceAddress_t));

                    (void)Gap_StopScanning();
#if defined(gAppUsePrivacy_d) && (gAppUsePrivacy_d)
                    gConnReqParams.usePeerIdentityAddress = pScanningEvent->eventData.extScannedDevice.advertisingAddressResolved;
#endif
                }
            }
        }
        break;

        case gScanStateChanged_c:
        {
            mScanningOn = !mScanningOn;

            /* Node starts scanning */
            if (mScanningOn)
            {
                mFoundDeviceToConnect = FALSE;

                shell_write("Scanning...\r\n");

#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
                /* Start scanning timer */
                (void)TMR_StartLowPowerTimer(mAppTimerId,
                           gTmrLowPowerSecondTimer_c,
                           TmrSeconds(gScanningTime_c),
                           ScanningTimeoutTimerCallback, NULL);
                Led1On();
#else
                LED_StopFlashingAllLeds();
                Led1Flashing();
#endif
            }
            /* Node is not scanning */
            else
            {
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
                tmrErrCode_t status = TMR_StopTimer(mAppTimerId);
                if(status != gTmrSuccess_c)
                {
                    panic(0, (uint32_t)BleApp_ScanningCallback, 0, 0);
                }
#endif

                shell_write("Scan stopped.\r\n");
                
                /* Connect with the previously scanned peer device */
                if (mFoundDeviceToConnect)
                {
                    shell_write("Connecting...\r\n");
                    /* Temporarily use minimum interval to speed up connection */
                    gConnReqParams.connIntervalMin = gGapConnIntervalMin_d;
                    gConnReqParams.connIntervalMax = gGapConnIntervalMin_d;
                    (void)App_Connect(&gConnReqParams, BleApp_ConnectionCallback);
                }
                else
                {
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
                    Led1Off();
                    /* Go to sleep */
                    (void)PWR_ChangeDeepSleepMode(cPWR_DeepSleepMode);
#else
                    LED_StopFlashingAllLeds();
                    Led1Flashing();
                    Led2Flashing();
                    Led3Flashing();
                    Led4Flashing();
#endif
                    shell_cmd_finished();
                }
            }
        }
        break;

        case gScanCommandFailed_c:
        {
            ; /* No action required */
        }
        break;

        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*! *********************************************************************************
* \brief        Handles BLE Connection callback from host stack.
*
* \param[in]    peerDeviceId        Peer device ID.
* \param[in]    pConnectionEvent    Pointer to gapConnectionEvent_t.
********************************************************************************** */
static void BleApp_ConnectionCallback (deviceId_t peerDeviceId, gapConnectionEvent_t* pConnectionEvent)
{
    /* Connection Manager to handle Host Stack interactions */
    BleConnManager_GapCentralEvent(peerDeviceId, pConnectionEvent);

    switch (pConnectionEvent->eventType)
    {
        case gConnEvtConnected_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(appConnectionCallbackEventData_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_ConnectionCallback_ConnEvtConnected_c;
                    pEventData->eventData.pData = pEventData + 1;
                    appConnectionCallbackEventData_t *pConnectionCallbackEventData = pEventData->eventData.pData;
                    pConnectionCallbackEventData->peerDeviceId = peerDeviceId;
                    FLib_MemCpy(&pConnectionCallbackEventData->pConnectedEvent, &pConnectionEvent->eventData.connectedEvent, sizeof(gapConnectedEvent_t));
                    pConnectionCallbackEventData = NULL;
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
        }
        break;

        case gConnEvtDisconnected_c:
        {
            BleApp_ConnectionCallback_SignalSimpleEvents(peerDeviceId, mAppEvt_ConnectionCallback_ConnEvtDisconnected_c);
        }
        break;

#if gAppUsePairing_d
        case gConnEvtLeScOobDataRequest_c:
        {
            BleApp_ConnectionCallback_SignalSimpleEvents(peerDeviceId, mAppEvt_ConnectionCallback_ConnEvtLeScOobDataRequest_c);
        }
        break;
        
        case gConnEvtPairingComplete_c:
        {
            /* Notify state machine handler on pairing complete */
            if (pConnectionEvent->eventData.pairingCompleteEvent.pairingSuccessful)
            {
                BleApp_ConnectionCallback_SignalSimpleEvents(peerDeviceId, mAppEvt_ConnectionCallback_ConnEvtPairingComplete_c);
            }
        }
        break;

#if defined(gAppUseBonding_d) && (gAppUseBonding_d)
        case gConnEvtEncryptionChanged_c:
        {
            if( pConnectionEvent->eventData.encryptionChangedEvent.newEncryptionState )
            {
                BleApp_ConnectionCallback_SignalSimpleEvents(peerDeviceId, mAppEvt_ConnectionCallback_ConnEvtEncryptionChanged_c);
            }
        }
        break;

        case gConnEvtAuthenticationRejected_c:
        {
            BleApp_ConnectionCallback_SignalSimpleEvents(peerDeviceId, mAppEvt_ConnectionCallback_ConnEvtAuthenticationRejected_c);
        }
        break;
#endif /* gAppUseBonding_d */
#endif /* gAppUsePairing_d */

        default:
            ; /* No action required */
            break;
    }
}

/*! *********************************************************************************
* \brief        Handles signaling of simple events (peerDeviceId and appEvent_t
*               connection event) from BLE Connection callback from host stack to the
*               application.
*
* \param[in]    peerDeviceId                     Peer device ID.
* \param[in]    connectionCallbackEvent          Event type.
********************************************************************************** */
static void BleApp_ConnectionCallback_SignalSimpleEvents
(
    deviceId_t peerDeviceId,
    appEvent_t connectionCallbackEvent
)
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
        if(pEventData != NULL)
        {
            pEventData->appEvent = connectionCallbackEvent;
            pEventData->eventData.peerDeviceId = peerDeviceId;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
}

/*! *********************************************************************************
* \brief        Handles discovered services.
*
* \param[in]    peerDeviceId        Peer device ID.
* \param[in]    pEvent              Pointer to servDiscEvent_t.
********************************************************************************** */
static void BleApp_ServiceDiscoveryCallback(deviceId_t peerDeviceId, servDiscEvent_t* pEvent)
{
    switch(pEvent->eventType)
    {
        /* Store the discovered handles for later use. */
        case gServiceDiscovered_c:
        {
            BleApp_StoreServiceHandles(peerDeviceId, pEvent->eventData.pService);
        }
        break;

        /* Service discovery has finished, run the state machine. */
        case gDiscoveryFinished_c:
        {
            if (pEvent->eventData.success)
            {
                if(mpfBleEventHandler != NULL)
                {
                    appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                    if(pEventData != NULL)
                    {
                        pEventData->appEvent = mAppEvt_ServiceDiscoveryCallback_DiscoveryFinishedWithSuccess_c;
                        pEventData->eventData.peerDeviceId = peerDeviceId;
                        (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                    }
                }
            }
            else
            {
                if(mpfBleEventHandler != NULL)
                {
                    appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                    if(pEventData != NULL)
                    {
                        pEventData->appEvent = mAppEvt_ServiceDiscoveryCallback_DiscoveryFinishedFailed_c;
                        pEventData->eventData.peerDeviceId = peerDeviceId;
                        (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                    }
                }
            }
        }
        break;

        default:
        {
            ; /* No action required */
        }
        break;
    }
}

/*! *********************************************************************************
* \brief        Stores handles for the specified service.
*
* \param[in]    peerDeviceId   Peer device ID.
* \param[in]    pService       Pointer to gattService_t.
********************************************************************************** */
static void BleApp_StoreServiceHandles
(
    deviceId_t      peerDeviceId,
    gattService_t   *pService
)
{
    uint8_t i;

    if ((pService->uuidType == gBleUuidType16_c) &&
        (pService->uuid.uuid16 == gBleSig_CCC_DK_UUID_d))
    {
        /* Found DK Service */
        maPeerInformation[peerDeviceId].customInfo.hDkService = pService->startHandle;
        for (i = 0; i < pService->cNumCharacteristics; i++)
        {
            if ((pService->aCharacteristics[i].value.uuidType == gBleUuidType128_c) &&
                FLib_MemCmp(pService->aCharacteristics[i].value.uuid.uuid128, uuid_char_vehicle_psm, 16))
            {
                /* Found Vehicle PSM Char */
                maPeerInformation[peerDeviceId].customInfo.hPsmChannelChar = pService->aCharacteristics[i].value.handle;

                maCharacteristics[mcCharVehiclePsmIndex_c].value.handle = maPeerInformation[peerDeviceId].customInfo.hPsmChannelChar;
                maCharacteristics[mcCharVehiclePsmIndex_c].value.maxValueLength = mcCharVehiclePsmLength_c;
                maCharacteristics[mcCharVehiclePsmIndex_c].value.paValue = (uint8_t *)&mValVehiclePsm;
            }
        }
        (void)GattClient_ReadCharacteristicValue(peerDeviceId, &maCharacteristics[mcCharVehiclePsmIndex_c], mcCharVehiclePsmLength_c);
    }
#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))
#if RECEIVE_RANGING_RESULT_FROM_VEHICLE
    else if((pService->uuidType == gBleUuidType128_c) && FLib_MemCmp(pService->uuid.uuid128, uuid_service_uwb, 16))
    {
        uint8_t j;
        /* Found UWB Service */
        maPeerInformation[peerDeviceId].customInfo.hUwbService = pService->startHandle;
        for (i = 0; i < pService->cNumCharacteristics; i++)
        {
            if ((pService->aCharacteristics[i].value.uuidType == gBleUuidType128_c) &&
                FLib_MemCmp(pService->aCharacteristics[i].value.uuid.uuid128, uuid_characteristic_ranging_result, 16))
            {
                /* Found uuid_characteristic_ranging_result */
                maPeerInformation[peerDeviceId].customInfo.hUwb = pService->aCharacteristics[i].value.handle;

                /*Search for the UWB Descriptors*/
                for (j = 0; j < pService->aCharacteristics[i].cNumDescriptors; j++) 
                {
                    if (pService->aCharacteristics[i].aDescriptors[j].uuidType == gBleUuidType16_c) 
                    {
                        switch (pService->aCharacteristics[i].aDescriptors[j].uuid.uuid16)
                        {
                            /* UWB struct Descriptor */
                            case gBleSig_CharPresFormatDescriptor_d: 
                            {
                                maPeerInformation[peerDeviceId].customInfo.hUwbDesc = pService->aCharacteristics[i].aDescriptors[j].handle;
                            }
                            break;
                            
                            case gBleSig_CCCD_d:
                            {
                                maPeerInformation[peerDeviceId].customInfo.hUwbCccd = pService->aCharacteristics[i].aDescriptors[j].handle;
                            }
                            break;
                            
                            default:
                            break;
                        }
                    }
                }
            }
        }
    }
#endif
#endif
    
}

/*! *********************************************************************************
* \brief        Handles GATT client callback from host stack.
*
* \param[in]    serverDeviceId      GATT Server device ID.
* \param[in]    procedureType       Procedure type.
* \param[in]    procedureResult     Procedure result.
* \param[in]    error               Callback result.
********************************************************************************** */
static void BleApp_GattClientCallback(
    deviceId_t              serverDeviceId,
    gattProcedureType_t     procedureType,
    gattProcedureResult_t   procedureResult,
    bleResult_t             error
)
{
    if (procedureResult == gGattProcError_c)
    {
        attErrorCode_t attError = (attErrorCode_t)(uint8_t)(error);

        if (attError == gAttErrCodeInsufficientEncryption_c     ||
            attError == gAttErrCodeInsufficientAuthorization_c  ||
            attError == gAttErrCodeInsufficientAuthentication_c)
        {
            /* Start Pairing Procedure */
            (void)Gap_Pair(serverDeviceId, &gPairingParameters);
        }

        if(mpfBleEventHandler != NULL)
        {
            appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
            if(pEventData != NULL)
            {
                pEventData->appEvent = mAppEvt_GattClientCallback_GattProcError_c;
                pEventData->eventData.peerDeviceId = serverDeviceId;
                (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
            }
        }
    }
    else
    {
        if (procedureResult == gGattProcSuccess_c)
        {           
            switch(procedureType)
            {
                case gGattProcReadCharacteristicValue_c:
                {
                    if(mpfBleEventHandler != NULL)
                    {
                        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                        if(pEventData != NULL)
                        {
                            pEventData->appEvent = mAppEvt_GattClientCallback_GattProcReadCharacteristicValue_c;
                            pEventData->eventData.peerDeviceId = serverDeviceId;
                            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                        }
                    }
                }
                break;
                case gGattProcReadUsingCharacteristicUuid_c:
                {
                    if(mpfBleEventHandler != NULL)
                    {
                        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                        if(pEventData != NULL)
                        {
                            pEventData->appEvent = mAppEvt_GattClientCallback_GattProcReadUsingCharacteristicUuid_c;
                            pEventData->eventData.peerDeviceId = serverDeviceId;
                            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                        }
                    }
                }
                break;

                default:
                {
                    if(mpfBleEventHandler != NULL)
                    {
                        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                        if(pEventData != NULL)
                        {
                            pEventData->appEvent = mAppEvt_GattClientCallback_GattProcComplete_c;
                            pEventData->eventData.peerDeviceId = serverDeviceId;
                            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                        }
                    }
                }
                break;
            }
        }
    }

    /* Signal Service Discovery Module */
    BleServDisc_SignalGattClientEvent(serverDeviceId, procedureType, procedureResult, error);
}

/*! *********************************************************************************
* \brief        Detect whether the provided data is found in the advertising data.
*
* \param[in]    pElement                    Pointer a to AD structure.
* \param[in]    pData                       Data to look for.
* \param[in]    iDataLen                    Size of data to look for.
*
* \return       TRUE if data matches, FALSE if not
********************************************************************************** */
static bool_t MatchDataInAdvElementList(gapAdStructure_t *pElement, void *pData, uint8_t iDataLen)
{
    uint32_t i;
    bool_t status = FALSE;

    for (i = 0; i < (uint32_t)pElement->length - 1UL; i += iDataLen)
    {
        /* Compare input data with advertising data. */
        if (FLib_MemCmp(pData, &pElement->aData[i], iDataLen))
        {
            status = TRUE;
            break;
        }
    }
    return status;
}

/*! *********************************************************************************
* \brief        Process scanning events to search for the DK Ranging Service.
*               This function is called from the scanning callback.
*
* \param[in]    pData                   Pointer to gapScannedDevice_t.
*
* \return       TRUE if the scanned device implements the DK Ranging Service,
                FALSE otherwise
********************************************************************************** */
static bool_t CheckScanEventLegacy(gapScannedDevice_t* pData)
{
    uint32_t index = 0;
    bool_t foundMatch = FALSE;
    uint8_t uuid_ranging_service[2] = {UuidArray(gBleSig_CCC_DK_UUID_d)};
    while (index < pData->dataLength)
    {
        gapAdStructure_t adElement;

        adElement.length = pData->data[index];
        adElement.adType = (gapAdType_t)pData->data[index + 1U];
        adElement.aData = &pData->data[index + 2U];

         /* Search for DK Ranging Service */
        if ((adElement.adType == gAdIncomplete16bitServiceList_c) ||
          (adElement.adType == gAdComplete16bitServiceList_c))
        {
            foundMatch = MatchDataInAdvElementList(&adElement, &uuid_ranging_service, 2);
        }

        /* Move on to the next AD element type */
        index += (uint32_t)adElement.length + sizeof(uint8_t);
    }

    if (foundMatch)
    {
        /* Update UI */
        shell_write("\r\nLegacy ADV: ");
        shell_writeHex(pData->aAddress, gcBleDeviceAddressSize_c);
        shell_write("\r\n");
    }
    return foundMatch;
}

/*! *********************************************************************************
* \brief        Process scanning events to search for the DK Ranging Service.
*               This function is called from the scanning callback.
*
* \param[in]    pData                   Pointer to gapExtScannedDevice_t.
*
* \return       TRUE if the scanned device implements the DK Ranging Service,
                FALSE otherwise
********************************************************************************** */
static bool_t CheckScanEventExtended(gapExtScannedDevice_t* pData)
{
    uint32_t index = 0;
    bool_t foundMatch = FALSE;
    uint8_t uuid_ranging_service[2] = {UuidArray(gBleSig_CCC_DK_UUID_d)};
    while (index < pData->dataLength)
    {
        gapAdStructure_t adElement;

        adElement.length = pData->pData[index];
        adElement.adType = (gapAdType_t)pData->pData[index + 1U];
        adElement.aData = &pData->pData[index + 2U];

         /* Search for DK Ranging Service */
        if ((adElement.adType == gAdIncomplete16bitServiceList_c) ||
          (adElement.adType == gAdComplete16bitServiceList_c))
        {
            foundMatch = MatchDataInAdvElementList(&adElement, &uuid_ranging_service, 2);
        }

        /* Move on to the next AD element type */
        index += (uint32_t)adElement.length + sizeof(uint8_t);
    }

    if (foundMatch)
    {
        /* Update UI */
        shell_write("\r\nExtended LR ADV: ");
        shell_writeHex(pData->aAddress, gcBleDeviceAddressSize_c);
        shell_write("\r\n");
    }
    return foundMatch;
}

/*! *********************************************************************************
* \brief        Stop scanning after a given time (gScanningTime_c).
                Called on timer task.
*
* \param[in]    pParam              not used
********************************************************************************** */
#if defined(cPWR_UsePowerDownMode) && (cPWR_UsePowerDownMode)
static void ScanningTimeoutTimerCallback(void* pParam)
{
    /* Stop scanning */
    if (mScanningOn)
    {
        (void)Gap_StopScanning();
    }
}
#endif

/*! *********************************************************************************
* \brief        Callback for incoming PSM data.
*
* \param[in]    deviceId        The device ID of the connected peer that sent the data
* \param[in]    lePsm           Channel ID
* \param[in]    pPacket         Pointer to incoming data
* \param[in]    packetLength    Length of incoming data
********************************************************************************** */
static void BleApp_L2capPsmDataCallback (deviceId_t     deviceId,
                                         uint16_t       lePsm,
                                         uint8_t*       pPacket,
                                         uint16_t       packetLength)
{
    if(mpfBleEventHandler != NULL)
    {
        appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(appEventL2capPsmData_t) + (uint32_t)packetLength);
        if(pEventData != NULL)
        {
            pEventData->appEvent = mAppEvt_L2capPsmDataCallback_c;
            pEventData->eventData.pData = pEventData + 1;
            appEventL2capPsmData_t *pL2capPsmDataEvent = pEventData->eventData.pData;
            pL2capPsmDataEvent->deviceId = deviceId;
            pL2capPsmDataEvent->lePsm = lePsm;
            pL2capPsmDataEvent->packetLength = packetLength;
            pL2capPsmDataEvent->pPacket = (uint8_t*)(pL2capPsmDataEvent + 1);
            FLib_MemCpy(pL2capPsmDataEvent->pPacket, pPacket, packetLength);
            pL2capPsmDataEvent = NULL;
            (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
        }
    }
}

/*! *********************************************************************************
* \brief        Callback for control messages.
*
* \param[in]    pMessage    Pointer to control message
********************************************************************************** */
static void BleApp_L2capPsmControlCallback(l2capControlMessage_t* pMessage)
{
    switch (pMessage->messageType)
    {
        case gL2ca_LePsmConnectRequest_c:
        {
            /* This message is unexpected, the DK Device sends Conn Req and expects a response */

            break;
        }
        case gL2ca_LePsmConnectionComplete_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(l2caLeCbConnectionComplete_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_L2capPsmControlCallback_LePsmConnectionComplete_c;
                    pEventData->eventData.pData = pEventData + 1;
                    FLib_MemCpy(pEventData->eventData.pData, &pMessage->messageData.connectionComplete, sizeof(l2caLeCbConnectionComplete_t));
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
            break;
        }
        case gL2ca_LePsmDisconnectNotification_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_L2capPsmControlCallback_LePsmDisconnectNotification_c;
                    pEventData->eventData.peerDeviceId = pMessage->messageData.disconnection.deviceId;
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
            break;
        }
        case gL2ca_NoPeerCredits_c:
        {
            if(mpfBleEventHandler != NULL)
            {
                appEventData_t *pEventData = MEM_BufferAlloc(sizeof(appEventData_t) + sizeof(l2caLeCbNoPeerCredits_t));
                if(pEventData != NULL)
                {
                    pEventData->appEvent = mAppEvt_L2capPsmControlCallback_NoPeerCredits_c;
                    pEventData->eventData.pData = pEventData + 1;
                    FLib_MemCpy(pEventData->eventData.pData, &pMessage->messageData.noPeerCredits, sizeof(l2caLeCbNoPeerCredits_t));
                    (void)App_PostCallbackMessage(mpfBleEventHandler, pEventData);
                }
            }
            break;
        }
        case gL2ca_Error_c:
        {
            /* Handle error */
            break;
        }
        default:
            ; /* For MISRA compliance */
            break;
    }
}


#if (defined(UWB_FEATURE_SUPPORT) && (UWB_FEATURE_SUPPORT == 1U))

#if RECEIVE_RANGING_RESULT_FROM_VEHICLE 

#define CRC16_POLYNOMIAL           (uint32_t)(0x00001021ul)
static uint16_t calculateCRC16Byte(uint8_t* DataBuff, uint16_t Len)
{
    uint8_t loopIndex = 0;
    uint8_t newByte;
    uint16_t i = 0;
    uint16_t CRCValue = 0;
  
    while( i < Len)
    {
        newByte = DataBuff[i];
        for(loopIndex = 0; loopIndex < 8; loopIndex++)
        {
            if(((CRCValue & 0x8000u) >> 8u) ^ (newByte & 0x80u))
            {
                CRCValue = (CRCValue << 1u) ^ (uint16_t)CRC16_POLYNOMIAL;
            }
            else
            {
                CRCValue = (CRCValue << 1u);
            }
            newByte <<= 1;
        }
        i++;
    }
    
    return CRCValue;
}
/*! *********************************************************************************
 * \brief        Enable UWB ranging result notifications by writing peer's CCCD of the
                 characteristic.
 *
 * \return       gBleSuccess_c or gBleOutOfMemory_c
 ********************************************************************************** */
bleResult_t BleApp_ConfigureNotifications(deviceId_t deviceId) 
{
    bleResult_t result = gBleSuccess_c;
    uint16_t value = (uint16_t) gCccdNotification_c;

    /* Allocate buffer for the write operation */
    if (mpCharProcBuffer == NULL) 
    {
        mpCharProcBuffer = MEM_BufferAlloc(sizeof(gattAttribute_t) + gAttDefaultMtu_c);
    }

    if(mpCharProcBuffer != NULL && maPeerInformation[deviceId].customInfo.hUwbCccd) 
    {
        mpCharProcBuffer->handle = maPeerInformation[deviceId].customInfo.hUwbCccd;
        mpCharProcBuffer->uuid.uuid16 = gBleSig_CCCD_d;
        mpCharProcBuffer->valueLength = 0;
        bleResult_t WriteChar_status = GattClient_WriteCharacteristicDescriptor(maPeerInformation[deviceId].deviceId, mpCharProcBuffer, sizeof(value), (void*) &value);
    } 
    else 
    {
        result = gBleOutOfMemory_c;
    }
    return result;
}

/*! *********************************************************************************
 * \brief        Handles GATT client notification callback from host stack.
 *
 * \param[in]    serverDeviceId              GATT Server device ID.
 * \param[in]    characteristicValueHandle   Handle.
 * \param[in]    aValue                      Pointer to value.
 * \param[in]    valueLength                 Value length.
 ********************************************************************************** */
static void BleApp_GattNotificationCallback
(
    deviceId_t serverDeviceId,
    uint16_t characteristicValueHandle, 
    uint8_t *aValue,
    uint16_t valueLength
) 
{    
    static uint8_t buf[16] = {0};
    uint16_t crc;
    
    if (characteristicValueHandle ==maPeerInformation[serverDeviceId].customInfo.hUwb)
    {
        buf[0] = 0x5E;
        buf[1] = 0x00;
        buf[2] = 0x01;
        buf[3] = 0x00;
        buf[4] = 0x06;
        buf[5] = aValue[0];
        buf[6] = aValue[1];
        
        crc = calculateCRC16Byte(buf,9);
        buf[9] = (uint8_t)(crc & 0x00FF);
        buf[10] = (uint8_t)((crc & 0xFF00) >> 8);
#if (gAppUseShellInApplication_d == 0) 
        (void)Serial_SyncWrite(gAppSerMgrIf, buf, 11);
#else
        shell_writeN(buf, 11);
        
//        mRanger4Distance = (uint16_t)aValue[0] | ((uint16_t)aValue[1] << 8);
//        shell_write("Distance is:");
//        shell_writeDec(mRanger4Distance);
//        shell_write("cm \r\n");
#endif
    }
}
#endif

/*! *********************************************************************************
 * \brief        Query Time Stamp from UWB
 *
 * \param[in]    deviceId   0xF0 & valid DeviceId: start ranging after get timestamp
                            valid DeviceId: get timestamp for peer device time sync        
 ********************************************************************************** */
void QueryUwbTimeStamp(deviceId_t deviceId)
{
    uint8_t freeListSize = 0; 
    
    /* record peer device id that needs time sync*/   
    if(TsPeerDeviceList.head >= TsPeerDeviceList.tail)
    {
        freeListSize = TsPeerDeviceList.maxListSize - (TsPeerDeviceList.head - TsPeerDeviceList.tail);
    }
    else
    {
        freeListSize = TsPeerDeviceList.tail - TsPeerDeviceList.head;
    }

    if(freeListSize != 0 )
    {
        TsPeerDeviceList.DeviceIdList[TsPeerDeviceList.head] = deviceId;
        TsPeerDeviceList.head++;
        if(TsPeerDeviceList.head >= TsPeerDeviceList.maxListSize)
        {
            TsPeerDeviceList.head = 0;
        }
                    
        /* Send command to get current timestamp from UWB*/
        Ranger4UciCmd_ProprietaryQueryTimeStamp();
    }
    else
    {
        /*list is full*/
        panic(0,(uint32_t)&QueryUwbTimeStamp, 0, 0);
    }
}

static void App_SetRangingSessionCfg(deviceId_t deviceId, SessionManagement_t * pSessionPara)
{
    uint8_t CfgSize = 0;
    static uint32_t uwbInitTime = 0;
    phscaR4CadsTypesIntf_ErrorCode_t en_Status = errorCode_Success;
    Ranger4Uci_SessionCfgStructure_t * pRangingSessionCfg;
    
    // Jia: It is better use list store the ranging session configurations, add configuration one by one.
    // But for this demo, we only needs set Ranging session once, so not use chain table yet, will optimize in next version.
    pRangingSessionCfg = MEM_BufferAlloc(sizeof(Ranger4Uci_SessionCfgStructure_t) * 30);
    
    FLib_MemSet((uint8_t *)pRangingSessionCfg, 0, sizeof(Ranger4Uci_SessionCfgStructure_t) * 30);
    
    //add configurations here
    FLib_MemCpy(pRangingSessionCfg, UwbSessionCfg, sizeof(UwbSessionCfg));
    
    CfgSize = NumberOfElements(UwbSessionCfg);
    
    //add UWB init time parameter
    pRangingSessionCfg[CfgSize].ID = R4_SESSION_UWB_INITIATION_TIME;
    pRangingSessionCfg[CfgSize].length = 4;
    // convert to millisecond 
    uwbInitTime = UWB_INITIATION_TIME_DEMO + 210; //100 milliseconds

    pRangingSessionCfg[CfgSize].paramValue = (uint8_t*)&uwbInitTime;   
    CfgSize++;

    en_Status = Ranger4UciCmd_MacSessionConfigure(pSessionPara->UwbSessionID, CfgSize, pRangingSessionCfg);
    
    MSG_Free(pRangingSessionCfg);
//    if( en_Status == errorCode_InvalidRange)
//    {
//        //too many configurations, split configurations 
//        Ranger4UciCmd_MacSessionConfigure(pSessionPara->UwbSessionID, CfgSize/2, pRangingSessionCfg);
//
//        Ranger4UciCmd_MacSessionConfigure(pSessionPara->UwbSessionID, (CfgSize/2 + (CfgSize%2)), &pRangingSessionCfg[CfgSize/2]);
//
//    }
//    else if(en_Status == errorCode_Undefined)
//    {
//        //Out of memory
//        panic(0,0,0,0);
//    }
  
}

/*! *********************************************************************************
 * \brief        Process Time Stamp get from UWB
 *
 * \param[in]    pPayload   point of UWB UCI response frame        
 ********************************************************************************** */
static void ProcessUwbTimeStamp(uint8_t * pPayload, phscaR4CadsTypesIntf_UciStatusCode_t StateCode)
{
    uint8_t PeerId = 0;
    union
    {
        uint8_t Buf[8];
        uint64_t TsValue;
    }TsUwbTime;
    
    FLib_MemCpy(TsUwbTime.Buf, &pPayload[0], 8);
    /* Get nearst Id of device that needs time sync  */
    PeerId  = TsPeerDeviceList.DeviceIdList[TsPeerDeviceList.tail];

    /* Update device list to next device ID */
    TsPeerDeviceList.tail++;      
    if(TsPeerDeviceList.tail >= TsPeerDeviceList.maxListSize)
    {
        TsPeerDeviceList.tail = 0;
    }
    
    if(StateCode != uciStatusCode_Ok)
    {
        QueryUwbTimeStamp(PeerId);
        return;
    }
    
    /* Update current timestamp */
    TsUwbCurrentTimeStamp = TsUwbTime.TsValue;    
    (void)Serial_Print(gAppSerMgrIf, "Uwb Current TimeStamp is:", gAllowToBlock_d);
Serial_PrintHex(gAppSerMgrIf, (uint8_t *)&TsUwbCurrentTimeStamp,8, gPrtHexNoFormat_c);
(void)Serial_Print(gAppSerMgrIf, "/r/n", gAllowToBlock_d); 

    if(PeerId < gAppMaxConnections_c)
    {   
        /* Subtract ble event delay */
        maPeerInformation[PeerId].TsUwbLocalDeviceTime = TsUwbTime.TsValue - (uint64_t)maPeerInformation[PeerId].TsBleEvtDelay;
        
        if( maPeerInformation[PeerId].NeedsSendTimeSyncForPhyUpdate )
        {
            (void)CCC_SendTimeSync(PeerId, 
                                   &maPeerInformation[PeerId].TsLocalDeviceEventCount, 
                                   &maPeerInformation[PeerId].TsUwbLocalDeviceTime, 
                                   1U); 
            maPeerInformation[PeerId].NeedsSendTimeSyncForPhyUpdate = false;
        }
    }
    else
    {
        PeerId = PeerId & 0x0F;
        if(PeerId < gAppMaxConnections_c)
        {
            /* start reference time is 100 milliseconds after the present time,give vehicle enought time to setup uwb */
            UwbSessions.UWB_Time0 = TsUwbCurrentTimeStamp + UWB_INITIATION_TIME_DEMO * 1000; 
            /* add Uncertainty time as max 4 milliseconds */
            UwbSessions.UWB_Time0 = UwbSessions.UWB_Time0 + (4u * 1000u);
            CCC_SendRangingSessionSetupRsp(PeerId, &UwbSessions);
            App_SetRangingSessionCfg(PeerId, &UwbSessions);
        }
    }
}

/*! *********************************************************************************
 * \brief        Extraction capability required by CCC capability exchange process              
 *
 * \param[in]    payload   point of UWB UCI response frame
 ***********************************************************************************/
static void GetCapabilityData(uint8_t *payload)
{
    uint8_t i, j, TlvCnt, TlvOffset; 
    
    TlvCnt = payload[1];    
    TlvOffset = 2;
    for(i = 0; i < TlvCnt; i++)
    {
        switch (payload[TlvOffset]) 
        {
            case R4_DEVICE_CAP_SLOT_BITMASK:
            {
                UwbCapability.Slot_bitMask = payload[TlvOffset+2];
            }
            break;
            
            case R4_DEVICE_CAP_SYNC_CODE_INDEX_BITMASK:
            {
                FLib_MemCpy(UwbCapability.SYNC_Code_Index_Bitmaks, &payload[TlvOffset+2], 4);
            }
            break;
            
            case R4_DEVICE_CAP_HOPPING_CONFIG_BITMASK:
            {
                UwbCapability.Hopping_Config_Bitmask = payload[TlvOffset+2];
            }
            break;
                
            case R4_DEVICE_CAP_CHANNEL_BITMASK: //Channel Bitmask
            {
                UwbCapability.Channel_BitMask = payload[TlvOffset+2];
            }
            break;
            
            case R4_DEVICE_CAP_SUPPORTED_PROTOCOL_VERSION: //Supported Protocol Version
            {
                UwbCapability.ProtoVer_Len = payload[TlvOffset + 1];
                for(j = 0; j < UwbCapability.ProtoVer_Len; j += 2)
                {
                    FLib_MemCpyReverseOrder(&UwbCapability.Supported_Protocol_Version[j],
                                            &payload[TlvOffset + 2 + j],
                                            2);
                }
            }
            break;
            
            case R4_DEVICE_CAP_SUPPORTED_UWB_CONFIG_ID: //Supported Configure Id
            {
                UwbCapability.CfgId_Len = payload[TlvOffset + 1];
                for(j = 0; j < UwbCapability.CfgId_Len; j += 2)
                {
                    FLib_MemCpy(&UwbCapability.Supported_Cfg_Id[j],
                                &payload[TlvOffset + 2 + j],
                                2);
                }
            }
            break;
            
            case R4_DEVICE_CAP_SUPPORTED_PULSESHAPE_COMBO: //Supported Pluse shape Combination
            {
                UwbCapability.PluseshapeCombo_Len = payload[TlvOffset + 1];
                FLib_MemCpy(UwbCapability.Supported_Pluseshape_Combo,
                            &payload[TlvOffset + 2],
                            UwbCapability.PluseshapeCombo_Len);
            }
            break;
            
            default:
                /* Other capability parameters are not used in this demo, ignore  */
            break;
        }
        
        TlvOffset += payload[TlvOffset + 1];//next TLV start point                        
        TlvOffset += 2; 
    }           
}

/*! *********************************************************************************
 * \brief        UCI response callback function, this function could be rework by 
 *               customer application code
 *
 * \param[in]    frame   UCI response frame
 ***********************************************************************************/
static void Ranger4App_RspCallback(phscaR4CadsTypesIntf_UciFrame_t * frame)
{
    phscaR4CadsTypesIntf_UciStatusCode_t StatusCode;
    uint8_t sGroupCode, sOpCode;
    
    StatusCode = (phscaR4CadsTypesIntf_UciStatusCode_t)frame->uciPacket.payload[0];
    sGroupCode = frame->uciPacket.header.groupId;
    sOpCode    = frame->uciPacket.header.opcodeId;
//    if(StatusCode == uciStatusCode_Ok)
//    {
        switch(sGroupCode)
        {
        case PHSCA_R4CADSTYPES_UCI_GID_CORE:
            switch (sOpCode)
            {
            case R4_UCI_CORE_OID_RESET_DEVICE:
                break;
            case R4_UCI_CORE_OID_CORE_GET_DEVICE_INFO:
                break;
            case R4_UCI_CORE_OID_CORE_GET_CAPS_INFO:
                if(StatusCode == uciStatusCode_Ok)
                {
                    if( mIsRanger4Init == false )
                    {
                        //set core configuration, to prevent UWB(NCJ29D5D) enter Low power mode
                        //just disable UWB enter low power mode 
                        Ranger4UciCmd_MacCoreSetConfiguration(UwbCoreCfgSize, UwbCoreCfg);
                    }
                    /* extract capability that required during CCC capability exchange */
                    GetCapabilityData(frame->uciPacket.payload);
                }
                break;
            case R4_UCI_CORE_OID_CORE_GET_CONFIG:
                break;
            case R4_UCI_CORE_OID_CORE_SET_CONFIG: 
                if(StatusCode == uciStatusCode_Ok)
                {
                    /* Set core configuration complete */
                    if( mIsRanger4Init == false )
                    {
                        /* Start UWB timer by calling query UWB timestamp command */
                        QueryUwbTimeStamp(gInvalidDeviceId_c);
                    }

//                    //Jia: Just for test UWB without BLE 
//                    UwbSessions.UwbSessionID = 0x01;
//                    Ranger4UciCmd_MacSessionCfgInit(UwbSessions.UwbSessionID, UwbSessions.SessionType);                 
                }
                else
                {}
                break;
            default:
                break;
            }
            break;
        case PHSCA_R4CADSTYPES_UCI_GID_SESSION_CONFIG:
            switch(sOpCode)
            {
            case R4_UCI_SESSION_CFG_OID_INIT://session init complete
                if(StatusCode == uciStatusCode_Ok)
                {   
//                    //Jia: Just for test UWB without BLE 
//                    Ranger4UciCmd_MacSessionConfigure(UwbSessions.UwbSessionID, 
//                                                      UwbSessions.SessionSetCfgSize,
//                                                      UwbSessions.pSessionCfg);
                }
                else
                {}
                break;
            case R4_UCI_SESSION_CFG_OID_SET_APP_CFG: //session config complete
                if(StatusCode == uciStatusCode_Ok)
                {
                    shell_write("\r\n ranging start, session ID is:\r\n");
                    shell_writeHex((uint8_t*)&UwbSessions.UwbSessionID,4);
                    shell_write("\r\n");
                    Ranger4UciCmd_MacSessionStartRanging(UwbSessions.UwbSessionID);
                }
                else
                {
                    
                }
                break;
            default:
                break;
            }
            break;
        case PHSCA_R4CADSTYPES_UCI_GID_RANGING_SESSION_CONTROL:
            switch(sOpCode)
            {
            case R4_UCI_RANGE_CTR_OID_START://session init complete
                break;
            case R4_UCI_RANGE_CTR_OID_STOP: //session config complete
                break;
            default:
                break;
            }            
            break;
        
        case PHSCA_R4CADSTYPES_UCI_GID_PROPRIETARY_MIN:
            switch(sOpCode)
            {
                case R4_UCI_PROPRIETARY_OID_QUERY_UWB_TIMESTAMP:
                {
                    if(StatusCode == uciStatusCode_Ok)
                    {
                        if( mIsRanger4Init == false )
                        {
                            mIsRanger4Init = true;
                        }
                    }

                    ProcessUwbTimeStamp(&frame->uciPacket.payload[1], StatusCode);
                }
                break;
                
                default:
                break;
            }
            break;
        default:
            break;
        }
//    }
//    else
//    {
//        /*process error code*/
//    }
}

/*! *********************************************************************************
 * \brief        UCI notification callback function, this function could be rework by 
 *               customer application code
 *
 * \param[in]    frame   UCI response frame
 ***********************************************************************************/
static void Ranger4App_NtfCallback(phscaR4CadsTypesIntf_UciFrame_t * frame)
{
    switch (frame->uciPacket.header.groupId)
    {
        case PHSCA_R4CADSTYPES_UCI_GID_CORE:
        {
            if(frame->uciPacket.header.opcodeId == R4_UCI_CORE_OID_CORE_DEVICE_STATUS_NTF)
            {
                //This state is the first state of UWBS after power ON/Reset or on receipt of DEVICE_RESET_CMD from host.
                mUwbDeviceStatus = (Ranger4Uci_DeviceStatusType_t)frame->uciPacket.payload[0];
                if(mUwbDeviceStatus >= R4_UCI_DEVICE_STATUS_NOT_SUPPORT)
                {
                    /* When the device type is not supported, only CORE_GET_DEVICE_INFO_CMD and CORE_RESET_DEVICE_CMD are 
                       supported, it need to check if UWB device support UCI in hardware level*/
                    panic(0, (uint32_t)Ranger4App_NtfCallback, mUwbDeviceStatus, 0);
                }
                else
                {
                    if(mUwbDeviceStatus == R4_UCI_DEVICE_STATUS_READY)
                    {
                        if(mIsRanger4Init == false)
                        {
                            /* UWB status is ready after ranger4 initialized, then read capability from UWB */
                            Ranger4UciCmd_MacCoreGetCapsInfo();
                            
                            /* Session variable init*/
                            UwbSessions.SessionStatus = R4_SESSION_STATE_DEINIT;
                            UwbSessions.UwbSessionID = 0;
                            UwbSessions.pSessionCfg = UwbSessionCfg;
                            UwbSessions.SessionSetCfgSize = NumberOfElements(UwbSessionCfg);
                            UwbSessions.SessionType = R4_SESSION_CCC_RANGING_SESSION;
                            UwbSessions.SelectedDkProtolVersion[0] = 0x01;
                            UwbSessions.SelectedDkProtolVersion[1] = 0x00;
                            UwbSessions.SelectedUwbConfigId = 0x0000;
                            UwbSessions.SelectedPulseShapeCombo = 0x11;
                            StopLed1Flashing();
                            StopLed2Flashing();
                            StopLed3Flashing();
                            StopLed4Flashing();
                        }
                        else
                        {
                            /* UWB status is ready, on other case */
                        }
                    }
                }
            }
            
            if(frame->uciPacket.header.opcodeId == R4_UCI_CORE_OID_CORE_GENERIC_ERROR_NTF)
            {
                /* This Notification is used in error situations when the error cannot 
                   be notified using an error status in a Response Message*/
            }
            break;
        }
            
        case PHSCA_R4CADSTYPES_UCI_GID_SESSION_CONFIG:
        {
            if(frame->uciPacket.header.opcodeId == R4_UCI_SESSION_CFG_OID_STATUS_NTF)
            {
                UwbSessions.UwbSessionID  = (uint32_t)frame->uciPacket.payload[0];
                UwbSessions.UwbSessionID |= ((uint32_t)frame->uciPacket.payload[1]) << 8;
                UwbSessions.UwbSessionID |= ((uint32_t)frame->uciPacket.payload[2]) << 16;
                UwbSessions.UwbSessionID |= ((uint32_t)frame->uciPacket.payload[3]) << 24;
                UwbSessions.SessionStatus = frame->uciPacket.payload[4];
                UwbSessions.SessionStatusChangeReason = frame->uciPacket.payload[5];
            }
            break;
        }
        case PHSCA_R4CADSTYPES_UCI_GID_RANGING_SESSION_CONTROL:
         {
             if(frame->uciPacket.header.opcodeId == R4_UCI_RANGE_CTR_OID_CCC_DATA_NTF)
             {
             }
             break;
         }
         case PHSCA_R4CADSTYPES_UCI_GID_PROPRIETARY_MIN:
         {    
             if(frame->uciPacket.header.opcodeId == R4_UCI_PROPRIETARY_OID_LOG_NTF)
             {
             }
             if(frame->uciPacket.header.opcodeId == R4_UCI_PROPRIETARY_OID_TEST_STOP_NTF)
             {
             }
             if(frame->uciPacket.header.opcodeId == R4_UCI_PROPRIETARY_OID_TEST_LOOPBACK_NTF)
             {
             }
             if(frame->uciPacket.header.opcodeId == R4_UCI_PROPRIETARY_OID_SET_TRIM_VALUE_NTF)
             {
             }
             break;
         }
         default:
             /*JIA: For other group notification, not sure how to handle it, just ignore it */
             break;
            
    }
}
#endif
/*! *********************************************************************************
* @}
********************************************************************************** */
